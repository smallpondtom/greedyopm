# NSE experiment: initial-condition perturbation robustness (our own data)

This reworks the Navier-Stokes example to (1) generate the cylinder-wake data
ourselves with a scikit-fem solver on the **existing mesh**, and (2) test the
manifolds for robustness to **initial-condition perturbations**: the manifolds
are fit on an unperturbed trajectory and evaluated on perturbed trajectories
whose reduced coordinates are pushed off the training distribution.

## Pipeline

```bash
# 0. one-time: add the FEM stack to the environment
pip install scikit-fem meshio          # (or add to pixi)

# 1. generate baseline + perturbed-IC trajectories (FOM, ~15 min)
python data_gen.py                     # writes gen/*.npy (full 42,764-DOF state)

# 2. compress to a shared lossless basis Q (method of snapshots)
python compress.py                     # writes data/compressed/{A_*, Q, cmean, meta}

# 3. run the perturbation-robustness experiment (resumable)
python run_pert.py all                 # budget, sweep, plots, report -> plots_pert/
```

## Physics / solver (`nse_solver.py`)

Incompressible Navier-Stokes, Taylor-Hood (P2 velocity / P1 pressure) on the
existing DOLFIN mesh `data/mesh/karman2D-outlets_lvl1.xml`, integrated with the
IPCS projection scheme (implicit diffusion, explicit convection, pressure
Poisson correction).  Re ~ 30, `nu = 1.667e-3`, parabolic inflow, no-slip
cylinder/walls, do-nothing outflow.  The mesh gives **41,682 interior velocity
DOFs**, matching the original data exactly.  The flow develops a steady cylinder
wake; the saved window is the transient.

## Perturbation design (`data_gen.py`)

A shared spin-up produces a developed state `s0`.  The **training** trajectory
evolves from `s0`; **validation** and **test** trajectories evolve from
`s0 + eps * rms * noise` on the interior velocity DOFs, for
`eps in {0.02, 0.04, 0.08, 0.16, 0.32}`.  The perturbation pushes the reduced
coordinates off the training distribution (excursion grows with `eps`).

The **validation** perturbation (`eps = 0.04`) tunes the Lipschitz budget, and
its reduced-coordinate excursion sets the certificate collar `delta` (see
`problem_pert.reduced_coord_excursion`).  The budget is selected to minimize the
validation (perturbed) reconstruction error, i.e. the largest budget that stays
robust.

## Result (see `plots_pert/`)

- **In-distribution** (unperturbed training): every manifold crushes POD
  (Greedy-CM 3e-8, Greedy-OPM p3 2e-3 vs POD 2e-2).
- **Perturbed**: the un-budgeted monomial manifolds (Greedy-QM, Greedy-CM,
  Geelen-QM) **blow up catastrophically** the moment any perturbation is applied,
  and worse as `r` grows (overfitting).  The **budgeted Greedy-OPM stays bounded
  and robust**, tracking POD's graceful degradation while keeping its large
  in-distribution accuracy advantage.  The Lipschitz budget is exactly what
  prevents the perturbation blow-up.

Figures: `nse_pert_error_vs_eps` (headline: error vs perturbation level),
`nse_pert_error_vs_r` (error vs r on train / perturbed splits),
`nse_pert_timing` (training time vs r), `nse_pert_field` (flow-field panels).

## Notes / caveats

- At Re ~ 30 the wake is steady, so a perturbed trajectory is out-of-distribution
  (it excites trailing modes the baseline-trained manifold cannot predict).  The
  achievable and honest result is therefore *robustness* (bounded, POD-like) plus
  the retained in-distribution advantage, not beating POD on deep-OOD states.  A
  vortex-shedding regime (Re > 47) would make the perturbed dynamics richer and
  the manifold's advantage larger; that is a natural extension.
- Compression floor: `Q` (K=600) represents the perturbed trajectories to a
  relative residual up to 5e-3 (`meta['proj_residual']`); all reported errors of
  interest are well above this floor.
- Full-state trajectories (`gen/*.npy`, ~1.1 GB) are not committed; regenerate
  with `data_gen.py`.  The compressed coordinates and `Q` are rebuilt by
  `compress.py`.
