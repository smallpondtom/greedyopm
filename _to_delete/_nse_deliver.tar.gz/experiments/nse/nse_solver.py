"""Incompressible Navier-Stokes solver on the cylinder mesh (scikit-fem, IPCS).

Taylor-Hood discretization (P2 velocity, P1 pressure) on the existing DOLFIN
cylinder mesh, integrated with the incremental pressure-correction (Chorin/Goda
IPCS) projection scheme: implicit diffusion, explicit convection and pressure
gradient, a pressure-Poisson correction, and an L2 velocity projection.  The
three constant operators are pre-factorized once on their interior DOFs (splu),
so each step is three sparse back-substitutions.

Geometry: channel [0,5] x [0,1] with a cylinder of radius 0.05 centered at
(2/3, 1/2).  Parabolic inflow at x=0, no-slip on top/bottom walls and cylinder,
do-nothing outflow at x=5 (pressure reference phi=0 there).
"""

from __future__ import annotations

import xml.etree.ElementTree as ET
from dataclasses import dataclass

import numpy as np
import scipy.sparse.linalg as spla

from skfem import (Basis, BilinearForm, LinearForm, MeshTri, ElementVector,
                   ElementTriP2, ElementTriP1, asm)
from skfem.helpers import dot, ddot, grad, div

CX, CY, CR = 2.0 / 3.0, 0.5, 0.05


def read_dolfin_mesh(xml_path: str) -> MeshTri:
    """Parse a legacy DOLFIN triangle mesh XML into a scikit-fem MeshTri."""
    root = ET.parse(xml_path).getroot()
    mesh_el = root.find("mesh")
    verts = mesh_el.find("vertices")
    nv = int(verts.get("size"))
    P = np.zeros((nv, 2))
    for v in verts.findall("vertex"):
        i = int(v.get("index"))
        P[i, 0] = float(v.get("x"))
        P[i, 1] = float(v.get("y"))
    tris = mesh_el.find("cells").findall("triangle")
    T = np.zeros((len(tris), 3), dtype=np.int64)
    for c in tris:
        i = int(c.get("index"))
        T[i] = [int(c.get("v0")), int(c.get("v1")), int(c.get("v2"))]
    return MeshTri(P.T, T.T)


# ---- forms ----------------------------------------------------------------


@BilinearForm
def _mass(u, v, w):
    return dot(u, v)


@BilinearForm
def _vlap(u, v, w):
    return ddot(grad(u), grad(v))         # vector Laplacian: sum_ij du_i/dx_j dv_i/dx_j


@BilinearForm
def _plap(p, q, w):
    return dot(grad(p), grad(q))


@BilinearForm
def _pgrad(p, v, w):
    return p * div(v)                     # trial pressure, test velocity


@LinearForm
def _conv(v, w):
    u = w["u"]
    gu = u.grad                           # gu[i, j] = du_i/dx_j
    adv = np.einsum("j...,ij...->i...", u.value, gu)   # (u.grad) u
    return dot(adv, v)


def _lu_interior(A_csr, dir_dofs, n):
    """Return (LU of A[I,I], interior idx I, coupling A[I,D]) for Dirichlet D."""
    mask = np.ones(n, dtype=bool)
    mask[dir_dofs] = False
    I = np.where(mask)[0]
    A = A_csr.tocsc()
    A_II = A[I][:, I]
    A_ID = A[I][:, dir_dofs]
    return spla.splu(A_II.tocsc()), I, A_ID.tocsr()


@dataclass
class NSConfig:
    nu: float = 1.667e-3
    dt: float = 1.0e-3
    u_max: float = 1.0
    ramp: float = 1.0


class CylinderNS:
    """IPCS incompressible Navier-Stokes on the cylinder mesh."""

    def __init__(self, mesh: MeshTri, cfg: NSConfig = NSConfig()):
        self.mesh = mesh
        self.cfg = cfg
        self.ub = Basis(mesh, ElementVector(ElementTriP2()), intorder=4)
        self.pb = Basis(mesh, ElementTriP1(), intorder=4)
        self._boundaries()
        self._assemble()

    def _boundaries(self):
        m = self.mesh
        f = m.facets
        mid = 0.5 * (m.p[:, f[0]] + m.p[:, f[1]])
        tol = 1e-6
        bnd = set(m.boundary_facets().tolist())

        def fac(mask):
            return np.array([i for i in np.where(mask)[0] if i in bnd],
                            dtype=np.int64)

        dist = np.sqrt((mid[0] - CX) ** 2 + (mid[1] - CY) ** 2)
        self.f_in = fac(np.abs(mid[0]) < tol)
        self.f_out = fac(np.abs(mid[0] - 5.0) < tol)
        self.f_wall = fac((np.abs(mid[1]) < tol) | (np.abs(mid[1] - 1.0) < tol))
        self.f_cyl = fac(dist < CR * 1.5)

        d_in = self.ub.get_dofs(self.f_in)
        d_wall = self.ub.get_dofs(self.f_wall)
        d_cyl = self.ub.get_dofs(self.f_cyl)
        self.vel_dir = np.unique(np.concatenate(
            [d_in.all(), d_wall.all(), d_cyl.all()]))
        self.pres_dir = self.pb.get_dofs(self.f_out).all()

        # inflow x-velocity dof bookkeeping
        allin = d_in.all()
        locs = self.ub.doflocs
        self._in_all = allin
        self._in_y = locs[1, allin]
        self._in_is_x = (allin % 2 == 0)

    def inflow_values(self, t: float) -> np.ndarray:
        u = self.ub.zeros()
        ramp = min(1.0, t / self.cfg.ramp) if self.cfg.ramp > 0 else 1.0
        prof = self.cfg.u_max * 4.0 * self._in_y * (1.0 - self._in_y) * ramp
        xdofs = self._in_all[self._in_is_x]
        u[xdofs] = prof[self._in_is_x]
        return u

    def _assemble(self):
        cfg = self.cfg
        self.M = asm(_mass, self.ub)
        self.K = asm(_vlap, self.ub)
        self.Lp = asm(_plap, self.pb)
        self.G = asm(_pgrad, self.pb, self.ub)          # (ub.N, pb.N)
        self.A_mom = (self.M / cfg.dt + cfg.nu * self.K).tocsr()

    def prepare(self):
        n_u, n_p = self.ub.N, self.pb.N
        self._mom = _lu_interior(self.A_mom, self.vel_dir, n_u)
        self._pp = _lu_interior(self.Lp, self.pres_dir, n_p)
        self._mass = _lu_interior(self.M, self.vel_dir, n_u)
        return self

    def _solve_dir(self, lu_pack, rhs, dir_dofs, dir_vals, n):
        lu, I, A_ID = lu_pack
        red = rhs[I] - A_ID @ dir_vals[dir_dofs]
        xI = lu.solve(red)
        x = np.zeros(n)
        x[dir_dofs] = dir_vals[dir_dofs]
        x[I] = xI
        return x

    def step(self, u_n, p_n, t):
        cfg = self.cfg
        n_u, n_p = self.ub.N, self.pb.N
        # 1) tentative velocity
        Nconv = asm(_conv, self.ub, u=self.ub.interpolate(u_n))
        rhs = self.M @ (u_n / cfg.dt) - Nconv + self.G @ p_n
        ubc = self.inflow_values(t + cfg.dt)
        u_star = self._solve_dir(self._mom, rhs, self.vel_dir, ubc, n_u)
        # 2) pressure correction (phi=0 at outflow)
        rhs_p = -(1.0 / cfg.dt) * (self.G.T @ u_star)
        phi = self._solve_dir(self._pp, rhs_p, self.pres_dir,
                              np.zeros(n_p), n_p)
        # 3) velocity correction
        rhs_u = self.M @ u_star + cfg.dt * (self.G @ phi)
        u_np1 = self._solve_dir(self._mass, rhs_u, self.vel_dir, ubc, n_u)
        return u_np1, p_n + phi

    def divergence_norm(self, u):
        return float(np.linalg.norm(self.G.T @ u))

    @property
    def n_interior_velocity(self):
        return int(self.ub.N - self.vel_dir.size)
