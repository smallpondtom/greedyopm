"""Budget selection balancing in-distribution accuracy and perturbed robustness.

The Lipschitz budget for each Greedy-OPM variant is tuned to be both accurate on
the unperturbed training trajectory and robust on the perturbed validation
trajectory.  A loose budget overfits the training trajectory and blows up on the
perturbed (out-of-distribution) states; a tight budget over-damps toward POD and
forfeits the manifold's in-distribution accuracy.  The objective is the
geometric mean of the training and validation reconstruction errors, minimized
over a grid of ``L`` evaluated cheaply through ``GreedyOPM.set_budget`` on a
single reference fit.
"""

from __future__ import annotations

import numpy as np

from methods import build_model

L_LO, L_HI = 1.5, 1.0e4
N_COARSE, N_REFINE = 12, 9


def select_budget(name, data, r_budget, delta, *, log=print) -> dict:
    """Grid-adaptive selection of ``L*`` minimizing validation recon error."""
    cfg_delta = dict(delta=delta)
    from methods import CFG
    cfg = dict(CFG, **cfg_delta)
    pm = build_model(name, data["train"], r_budget, cfg=cfg, L=L_HI)
    Strain, Sval = data["train"], data["val"]

    curve = []

    def err_at(L):
        pm.model.set_budget(float(L))
        et = float(pm.reconstruction_error(Strain, relative=True))
        ev = float(pm.reconstruction_error(Sval, relative=True))
        curve.append(dict(L=float(L), train=et, val=ev, objective=ev,
                          n_active=int(pm.n_active_nonlinear),
                          certificate=float(pm.certificate_)))
        return ev

    grid = np.geomspace(L_LO, L_HI, N_COARSE)
    errs = [err_at(L) for L in grid]
    i = int(np.argmin(errs))
    L_star, best = float(grid[i]), errs[i]
    lo = float(grid[max(i - 1, 0)])
    hi = float(grid[min(i + 1, N_COARSE - 1)])
    for L in np.linspace(lo, hi, N_REFINE):
        e = err_at(L)
        if e < best:
            best, L_star = e, float(L)
    log(f"    [{name}] L*={L_star:.3g} objective={best:.3e} "
        f"(delta={delta:.3g})", flush=True)
    return dict(L_star=float(L_star), best_objective=float(best),
                curve=sorted(curve, key=lambda d: d["L"]))
