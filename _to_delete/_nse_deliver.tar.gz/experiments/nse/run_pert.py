"""Driver: NSE initial-condition perturbation robustness (our own data).

Fits every manifold on the unperturbed training trajectory and measures the
relative full-state reconstruction error on the training trajectory and on the
perturbed test trajectories at several noise levels.  The certified Greedy-OPM
budget is selected on the perturbed validation split, whose reduced-coordinate
excursion sets the certificate collar ``delta``.

Phases (resumable JSON): ``budget``, ``sweep``, ``plots``, ``report``, ``all``.
Usage:  python run_pert.py [phase]
"""

from __future__ import annotations

import json
import sys
import time
from pathlib import Path

import numpy as np
import jax

jax.config.update("jax_enable_x64", True)

_HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(_HERE))
sys.path.insert(0, str(_HERE.parent.parent / "src"))

from methods import CFG, METHOD_NAMES, OPM_DEGREES, build_model, n_active, active_by_degree  # noqa: E402
import problem_pert as P                                   # noqa: E402
from budget_select_pert import select_budget               # noqa: E402

PLOTS = _HERE / "plots_pert"
CKPT = PLOTS / "results.json"
CKPT_B = PLOTS / "budget.json"
REPORT = PLOTS / "report.json"

R_MAX = 10
RS = list(range(1, R_MAX + 1))
R_BUDGET = 10
OPM_METHODS = tuple(OPM_DEGREES.keys())

MCFG = dict(CFG)
MCFG.update(s_pool=30, n_grad_samples=200, n_reorth=3)


def _load(p): return json.loads(p.read_text()) if p.exists() else {}
def _save(p, o): p.parent.mkdir(parents=True, exist_ok=True); p.write_text(json.dumps(o, indent=0))


def _delta(data):
    exc = P.reduced_coord_excursion(data, R_BUDGET)
    d = float(np.clip(exc["val"], 0.05, 0.3))
    return d, exc


def run_budget(data):
    study = _load(CKPT_B)
    delta, exc = _delta(data)
    study["_delta"] = delta
    study["_excursion"] = exc
    for name in OPM_METHODS:
        if name in study and "L_star" in study[name]:
            print(f"  [budget] {name}: cached L*={study[name]['L_star']:.3g}", flush=True)
            continue
        tic = time.time()
        rec = select_budget(name, data, R_BUDGET, delta, log=print)
        rec["secs"] = round(time.time() - tic, 1)
        study[name] = rec
        _save(CKPT_B, study)
    return study


def resolve(study):
    Ls = {n: study[n]["L_star"] for n in OPM_METHODS if n in study}
    return Ls, study["_delta"]


def run_sweep(data, Ls, delta):
    results = _load(CKPT)
    test_splits = data["_meta"]["test_splits"]
    eval_splits = ["train", "val"] + test_splits
    cfg = dict(MCFG, delta=delta)
    for r in RS:
        for name in METHOD_NAMES:
            key = f"{name}@r={r}"
            if key in results:
                continue
            tic = time.time()
            L = Ls.get(name) if name in OPM_METHODS else None
            m = build_model(name, data["train"], r, cfg=cfg, L=L)
            secs = round(time.time() - tic, 2)
            errs = {sp: float(m.reconstruction_error(data[sp], relative=True))
                    for sp in eval_splits}
            results[key] = dict(method=name, r=r, secs=secs,
                                n_active=n_active(m),
                                certificate=getattr(m, "certificate_", None),
                                **errs)
            _save(CKPT, results)
            print(f"  r={r:2d} {name:16s} train={errs['train']:.2e} "
                  f"val={errs['val']:.2e} "
                  f"test0.32={errs.get('test_0.32', float('nan')):.2e} "
                  f"({secs}s)", flush=True)
    return results


def run_plots(data, delta):
    from plots_pert import error_vs_r, error_vs_pert, timing_vs_r, field_panels
    results = _load(CKPT)
    study = _load(CKPT_B)
    error_vs_r(results, RS, METHOD_NAMES, data, str(PLOTS / "nse_pert_error_vs_r"))
    error_vs_pert(results, R_MAX, METHOD_NAMES, data, str(PLOTS / "nse_pert_error_vs_eps"))
    timing_vs_r(results, RS, METHOD_NAMES, str(PLOTS / "nse_pert_timing"))
    field_panels(data, R_MAX, resolve(study)[0], delta, MCFG,
                 str(PLOTS / "nse_pert_field"))


def run_report(data, Ls, delta):
    results = _load(CKPT); study = _load(CKPT_B)
    test_splits = data["_meta"]["test_splits"]
    errors = {n: {str(r): {sp: results[f"{n}@r={r}"][sp]
                           for sp in (["train", "val"] + test_splits)}
                  for r in RS if f"{n}@r={r}" in results} for n in METHOD_NAMES}
    timing = {n: {str(r): results[f"{n}@r={r}"]["secs"] for r in RS
                  if f"{n}@r={r}" in results} for n in METHOD_NAMES}
    rep = dict(experiment="nse_perturbation_robustness",
               d_full=data["_meta"]["d"], K=data["_meta"]["K"],
               eps=data["_meta"]["eps"], val_eps=P.VAL_EPS,
               delta=delta, selected_budgets=Ls,
               proj_residual=data["_meta"]["proj_residual"],
               excursion=study.get("_excursion"),
               errors=errors, training_times_s=timing)
    _save(REPORT, rep)
    print(f"    saved {REPORT.name}", flush=True)
    return rep


def main(phase="all"):
    data = P.make_dataset()
    print(f"[nse-pert] d={data['_meta']['d']} K={data['_meta']['K']} "
          f"train{data['train'].shape} test_levels={data['_meta']['pert_eps']}",
          flush=True)
    if phase in ("all", "budget"):
        run_budget(data)
    study = _load(CKPT_B)
    Ls, delta = resolve(study)
    print(f"[nse-pert] delta={delta:.3g} budgets: "
          + ", ".join(f"{k}->{v:.3g}" for k, v in Ls.items()), flush=True)
    if phase in ("all", "sweep"):
        run_sweep(data, Ls, delta)
    if phase in ("all", "plots"):
        run_plots(data, delta)
    if phase in ("all", "report"):
        run_report(data, Ls, delta)
    print("DONE", flush=True)


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "all")
