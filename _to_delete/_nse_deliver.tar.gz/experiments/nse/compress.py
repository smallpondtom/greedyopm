"""Compress the generated NSE trajectories to a shared lossless basis.

Following the method-of-snapshots compression of the original experiment: build
an orthonormal basis Q of the span of (a strided subsample of) all generated
snapshots (baseline + perturbed), centered by the baseline mean.  Because Q is
an isometry on that span, projecting every trajectory to A = Q^T (S - c) lets
all inner-product / SVD / least-squares methods reproduce the full-state errors
exactly while the working dimension drops from d to K.  The per-trajectory
projection residual is reported so the compression floor is auditable.
"""

import json
import glob
import os

import numpy as np

GEN = "gen"
OUT = "compressed"
os.makedirs(OUT, exist_ok=True)
K = 600
SUB = 3            # subsample stride for building Q


def main():
    meta = json.load(open(f"{GEN}/meta.json"))
    eps = meta["eps"]
    tags = ["baseline"] + [f"pert_{e:.2f}" for e in eps if e != 0.0]
    paths = {t: f"{GEN}/{t}.npy" for t in tags}

    # centering: baseline mean
    Sb = np.load(paths["baseline"], mmap_mode="r")
    c = np.asarray(Sb).mean(axis=1, keepdims=True).astype(np.float64)

    # build Q from a strided union (method of snapshots)
    cols = []
    for t in tags:
        S = np.load(paths[t], mmap_mode="r")
        cols.append(np.asarray(S[:, ::SUB], dtype=np.float64) - c)
    X = np.concatenate(cols, axis=1)              # (d, ns)
    print("Q-building matrix:", X.shape, flush=True)
    G = X.T @ X                                   # (ns, ns) Gram
    w, V = np.linalg.eigh(G)
    order = np.argsort(w)[::-1]
    w = np.clip(w[order], 0, None)
    V = V[:, order]
    sig = np.sqrt(w)
    k = min(K, int(np.sum(sig > sig[0] * 1e-9)))
    Q = (X @ V[:, :k]) / np.maximum(sig[:k], 1e-30)[None, :]   # (d, k)
    # re-orthonormalize (numerical safety)
    Q, _ = np.linalg.qr(Q)
    print(f"basis Q: d={Q.shape[0]} K={Q.shape[1]}", flush=True)

    # project every full-resolution trajectory
    data = {}
    resid = {}
    for t in tags:
        S = np.asarray(np.load(paths[t]), dtype=np.float64)
        Xc = S - c
        A = Q.T @ Xc                              # (K, n)
        rec = Q @ A
        rel = float(np.linalg.norm(Xc - rec) / np.linalg.norm(Xc))
        data[t] = A.astype(np.float64)
        resid[t] = rel
        np.save(f"{OUT}/A_{t}.npy", A.astype(np.float64))
        print(f"  {t}: A{A.shape}  proj_residual_rel={rel:.2e}", flush=True)

    np.save(f"{OUT}/Q.npy", Q.astype(np.float32))
    np.save(f"{OUT}/cmean.npy", c.astype(np.float32))
    out_meta = dict(meta, K=int(Q.shape[1]), tags=tags,
                    proj_residual=resid,
                    nrm=float(np.linalg.norm(np.load(paths["baseline"]) - c)))
    json.dump(out_meta, open(f"{OUT}/meta.json", "w"), indent=2)
    print("compression done", flush=True)


if __name__ == "__main__":
    main()
