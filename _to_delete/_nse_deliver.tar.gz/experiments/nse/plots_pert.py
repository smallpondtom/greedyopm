"""Plots for the NSE perturbation-robustness experiment (journal style)."""

from __future__ import annotations

import xml.etree.ElementTree as ET
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt          # noqa: E402
import matplotlib.tri as mtri            # noqa: E402

from methods import METHOD_STYLES, build_model  # noqa: E402
import problem_pert as P                 # noqa: E402

plt.rcParams.update({
    "font.family": "serif", "mathtext.fontset": "cm",
    "axes.labelsize": 17, "axes.titlesize": 16,
    "xtick.labelsize": 13, "ytick.labelsize": 13, "legend.fontsize": 12,
    "xtick.direction": "in", "ytick.direction": "in",
    "lines.linewidth": 2.2, "savefig.dpi": 300, "savefig.bbox": "tight",
    "pdf.fonttype": 42,
})

_CAP = 3.0            # display cap for diverged reconstructions
_HERE = Path(__file__).resolve().parent


def _save(fig, out):
    Path(out).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out + ".png"); fig.savefig(out + ".pdf"); plt.close(fig)


def _clip(v):
    v = float(v)
    return min(v, _CAP) if np.isfinite(v) else _CAP


def error_vs_r(results, RS, methods, data, out):
    splits = [("train", "Training (unperturbed)"),
              ("test_0.04", r"Perturbed test $\varepsilon=0.04$"),
              ("test_0.16", r"Perturbed test $\varepsilon=0.16$")]
    fig, axes = plt.subplots(1, 3, figsize=(16.5, 5.0), sharey=True)
    for ax, (sp, title) in zip(axes, splits):
        for name in methods:
            st = METHOD_STYLES.get(name, dict(fmt="-o", color="gray", lw=2, ms=6))
            xs = [r for r in RS if f"{name}@r={r}" in results]
            ys = [_clip(results[f"{name}@r={r}"][sp]) for r in xs]
            if xs:
                ax.plot(xs, ys, st["fmt"], color=st["color"], lw=st["lw"],
                        ms=st["ms"], label=name)
        ax.set_yscale("log"); ax.set_xlabel(r"reduced dimension $r$")
        ax.set_title(title); ax.grid(True, which="both", ls=":", alpha=0.4)
        ax.axhline(_CAP, color="k", ls="--", lw=0.8, alpha=0.5)
    axes[0].set_ylabel("relative state error")
    axes[0].legend(loc="best", framealpha=0.92)
    _save(fig, out)


def error_vs_pert(results, r, methods, data, out):
    eps = data["_meta"]["eps"]
    xs = eps
    fig, ax = plt.subplots(figsize=(8.2, 6.0))
    for name in methods:
        st = METHOD_STYLES.get(name, dict(fmt="-o", color="gray", lw=2, ms=6))
        ys = []
        for e in eps:
            sp = "train" if e == 0.0 else f"test_{e:.2f}"
            key = f"{name}@r={r}"
            ys.append(_clip(results[key][sp]) if key in results else np.nan)
        ax.plot(xs, ys, st["fmt"], color=st["color"], lw=st["lw"], ms=st["ms"], label=name)
    ax.set_yscale("log")
    ax.set_xlabel(r"IC perturbation level $\varepsilon$")
    ax.set_ylabel(r"relative state error at $r=%d$" % r)
    ax.grid(True, which="both", ls=":", alpha=0.4)
    ax.axhline(_CAP, color="k", ls="--", lw=0.8, alpha=0.5)
    ax.legend(loc="best", framealpha=0.92)
    fig.text(0.5, -0.02, r"$\varepsilon=0$ is the unperturbed training trajectory; "
             r"errors $\geq %.0f$ shown clipped" % _CAP, ha="center", fontsize=11)
    _save(fig, out)


def timing_vs_r(results, RS, methods, out):
    fig, ax = plt.subplots(figsize=(8.2, 6.0))
    for name in methods:
        st = METHOD_STYLES.get(name, dict(fmt="-o", color="gray", lw=2, ms=6))
        xs = [r for r in RS if f"{name}@r={r}" in results]
        ys = [results[f"{name}@r={r}"]["secs"] for r in xs]
        if xs:
            ax.plot(xs, ys, st["fmt"], color=st["color"], lw=st["lw"], ms=st["ms"], label=name)
    ax.set_yscale("log")
    ax.set_xlabel(r"reduced dimension $r$")
    ax.set_ylabel("training time (s)")
    ax.grid(True, which="both", ls=":", alpha=0.4)
    ax.legend(loc="best", framealpha=0.92)
    _save(fig, out)


# ---- field panels ----------------------------------------------------------


def _read_vertices():
    xml = _HERE / "data" / "karman2D-outlets_lvl1.xml"
    root = ET.parse(xml).getroot().find("mesh")
    verts = root.find("vertices"); nv = int(verts.get("size"))
    Pp = np.zeros((nv, 2))
    for v in verts.findall("vertex"):
        i = int(v.get("index")); Pp[i, 0] = float(v.get("x")); Pp[i, 1] = float(v.get("y"))
    tris = root.find("cells").findall("triangle")
    T = np.zeros((len(tris), 3), dtype=np.int64)
    for c in tris:
        i = int(c.get("index")); T[i] = [int(c.get("v0")), int(c.get("v1")), int(c.get("v2"))]
    return Pp, T


def field_panels(data, r, Ls, delta, cfg, out):
    Q, c = P.load_lifting()
    Q = Q.astype(np.float64); c = c.astype(np.float64).ravel()
    Pp, T = _read_vertices()
    nv = Pp.shape[0]
    tri = mtri.Triangulation(Pp[:, 0], Pp[:, 1], T)
    vx = np.arange(0, 2 * nv, 2); vy = vx + 1

    def speed_full(a_hat):
        full = Q @ np.asarray(a_hat) + c
        return np.sqrt(full[vx] ** 2 + full[vy] ** 2)

    split = "test_0.08"
    A = data[split]
    # a representative snapshot: median excursion from the training trajectory
    exc = np.linalg.norm(A - data["train"][:, :A.shape[1]], axis=0)
    col = int(np.argsort(exc)[int(0.6 * exc.size)])
    a_true = A[:, col]

    panels = [("Truth", a_true, None)]
    for name in ["POD", "Greedy-CM", "Greedy-OPM (p=3)"]:
        L = Ls.get(name) if name in Ls else None
        m = build_model(name, data["train"], r, cfg=dict(cfg, delta=delta), L=L)
        a_hat = np.asarray(m.reconstruct(a_true[:, None]))[:, 0]
        err = float(np.linalg.norm(a_hat - a_true) / np.linalg.norm(a_true))
        panels.append((f"{name}\nrel err {err:.2e}", a_hat, err))

    vmax = float(np.max(speed_full(a_true)))
    fig, axes = plt.subplots(len(panels), 1, figsize=(11, 2.1 * len(panels)))
    for ax, (title, a, _) in zip(np.atleast_1d(axes), panels):
        sp = speed_full(a)
        tpc = ax.tripcolor(tri, np.clip(sp, 0, 2 * vmax), shading="gouraud",
                           cmap="turbo", vmin=0, vmax=vmax)
        ax.set_title(title, fontsize=13); ax.set_aspect("equal")
        ax.set_xticks([]); ax.set_yticks([])
        fig.colorbar(tpc, ax=ax, fraction=0.02)
    fig.suptitle(rf"Perturbed snapshot ($\varepsilon=0.08$), $r={r}$", fontsize=14)
    _save(fig, out)
