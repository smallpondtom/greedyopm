"""Generate baseline + perturbed-IC NSE trajectories on the cylinder mesh."""
import time, json, numpy as np
from nse_solver import read_dolfin_mesh, CylinderNS, NSConfig

OUT = "gen"; import os; os.makedirs(OUT, exist_ok=True)
cfg = NSConfig(nu=1.667e-3, dt=1e-3, u_max=1.5, ramp=0.5)
T0 = 0.75            # spin-up to a developed transient state s0
T_WIN = 2.25         # saved window length
STRIDE = 2           # save every STRIDE steps
EPS = [0.0, 0.02, 0.04, 0.08, 0.16, 0.32]   # IC perturbation levels (0 = baseline)
SEED0 = 100

m = read_dolfin_mesh("karman2D-outlets_lvl1.xml")
ns = CylinderNS(m, cfg).prepare()
nstep_spin = int(round(T0/cfg.dt)); nstep_win = int(round(T_WIN/cfg.dt))
n_u = ns.ub.N

# interior velocity dofs (perturb only these)
mask = np.ones(n_u, bool); mask[ns.vel_dir] = False
interior = np.where(mask)[0]

print(f"spin-up {nstep_spin} steps to t0={T0}", flush=True)
u = ns.ub.zeros(); p = ns.pb.zeros(); t0=time.time()
for k in range(nstep_spin):
    u, p = ns.step(u, p, k*cfg.dt)
s0 = u.copy(); p0 = p.copy()
np.save(f"{OUT}/s0.npy", s0.astype(np.float32))
print(f"  spin-up done in {time.time()-t0:.0f}s, |s0|max={np.abs(s0).max():.3f}", flush=True)
rms = float(np.std(s0[interior]))

def run_window(u_init, p_init):
    u = u_init.copy(); p = p_init.copy(); snaps=[]
    for k in range(nstep_win):
        t = T0 + k*cfg.dt
        u, p = ns.step(u, p, t)
        if k % STRIDE == 0:
            snaps.append(u.astype(np.float32))
    return np.array(snaps).T   # (d, n)

meta = dict(nu=cfg.nu, dt=cfg.dt, u_max=cfg.u_max, T0=T0, T_win=T_WIN,
            stride=STRIDE, eps=EPS, rms_s0=rms, d=int(n_u),
            interior=int(interior.size))
for i, eps in enumerate(EPS):
    tic=time.time()
    if eps == 0.0:
        u_ic = s0.copy()
    else:
        rng = np.random.default_rng(SEED0 + i)
        pert = np.zeros(n_u); pert[interior] = rng.standard_normal(interior.size)
        u_ic = s0 + eps * rms * pert
    S = run_window(u_ic, p0)
    tag = "baseline" if eps==0.0 else f"pert_{eps:.2f}"
    np.save(f"{OUT}/{tag}.npy", S)
    # distance-to-baseline diagnostic saved later; report shape
    print(f"[{tag}] eps={eps} S{S.shape} in {time.time()-tic:.0f}s "
          f"|S|max={np.abs(S).max():.3f}", flush=True)
json.dump(meta, open(f"{OUT}/meta.json","w"), indent=2)
print("DONE", flush=True)
