"""Manifold + ROM adapters for the OpInf experiment.

Each method contributes a *manifold* (fit once, jointly, on the training
trajectories) and a *nonlinear feature map* that both the manifold decoder and
the reduced model share.  Two reduced models are built on every manifold:

* **Plain latent OpInf** (Geelen-style): evolve the encoder coordinates with
  ``d/dt shat = c + A shat + N p(shat)``.  This is the requested baseline; for a
  polynomial manifold on the advection problem it is dynamically unstable.

* **RPG-OpInf** (geometric manifold-Galerkin): evolve
  ``d/dt shat = M(shat)^{-1} (a(shat) + J_p^T b(shat))`` with mass matrix
  ``M = I + J_p^T Vbar^T Vbar J_p`` and non-intrusive operators ``a = V^T f``,
  ``b = Vbar^T f``.  The mass matrix is bounded by the Lipschitz budget
  (``||M - I|| <= L^2 - 1``), so a tight budget keeps the ROM stable -- this is
  where the manifold's certified geometry earns its keep during simulation.

Both models share the manifold's decoder and its active polynomial features.
"""

from __future__ import annotations

from typing import Dict, Optional

import numpy as np

from methods import build_model, CFG   # noqa: F401
import rom
from findiff import fbct4

OPINF_METHODS = [
    "POD",
    "Greedy-QM",
    "Greedy-CM",
    "Greedy-OPM (p=2)",
    "Greedy-OPM (p=3)",
]
OPM_NAMES = ("Greedy-OPM (p=2)", "Greedy-OPM (p=3)")

ROM_DEGREES = {
    "POD": "constant + linear",
    "Greedy-QM": "constant + linear + quadratic",
    "Greedy-CM": "constant + linear + cubic",
    "Greedy-OPM (p=2)": "constant + linear + quadratic",
    "Greedy-OPM (p=3)": "constant + linear + quadratic + cubic",
}

LAM_ORTHO = dict(lam_const=0.0, lam_lin=1e-10, lam_nl=1e-10)
LAM_MONO = dict(lam_const=0.0, lam_lin=1e-10, lam_nl=1e-8)


def _feature_and_jac(name: str, inner):
    """Return ``(feature_fn, feature_jac_fn, Vbar)`` for a fitted manifold.

    ``feature_fn(s) -> p``, ``feature_jac_fn(s) -> (p, J_p)``, and ``Vbar`` is
    the ``(d, q)`` lifting matrix whose columns pair with the ``q`` features.
    ``POD`` has no manifold -> ``(None, None, None)``.
    """
    if name == "POD":
        return None, None, None
    if name in OPM_NAMES:
        return (rom.opm_feature_fn(inner),
                rom.opm_feature_jac_fn(inner),
                np.asarray(inner.Vbar_nl_))
    if name == "Greedy-QM":
        return (rom.monomial_feature_fn("quadratic"),
                rom.monomial_feature_jac_fn("quadratic"),
                np.asarray(inner.Vbar_))
    if name == "Greedy-CM":
        return (rom.monomial_feature_fn("cubic"),
                rom.monomial_feature_jac_fn("cubic"),
                np.asarray(inner.Vbar_))
    if name == "Geelen-QM":
        act = inner.active_
        return (rom.monomial_feature_fn("quadratic", active=act),
                rom.monomial_feature_jac_fn("quadratic", active=act),
                np.asarray(inner.Vbar_))
    raise ValueError(f"Unknown method {name!r}")


class ManifoldROM:
    """A fitted manifold with both a plain and a geometric (RPG) reduced model."""

    def __init__(self, name: str, r: int, S_fit: np.ndarray,
                 *, L: Optional[float] = None, cfg: dict = CFG):
        self.name = name
        self.r = int(r)
        self.pm = build_model(name, S_fit, r, cfg=cfg, L=L)
        self.inner = self.pm.model
        self.normalizer = self.pm.normalizer
        self.feature_fn, self.feature_jac_fn, self.Vbar = _feature_and_jac(name, self.inner)
        self.has_manifold = self.Vbar is not None
        self.lam = LAM_ORTHO if name in OPM_NAMES else LAM_MONO
        self.G_lift = (self.Vbar.T @ self.Vbar) if self.has_manifold else None
        self.n_features = int(getattr(self.inner, "n_active_nonlinear", 0))
        self.certificate = float(getattr(self.inner, "certificate_", np.nan))

    def set_budget(self, L: float):
        """Recalibrate an OPM manifold's budget and refresh the ROM feature data."""
        self.inner.set_budget(L)
        self.feature_fn, self.feature_jac_fn, self.Vbar = _feature_and_jac(self.name, self.inner)
        self.G_lift = (self.Vbar.T @ self.Vbar) if self.has_manifold else None
        self.n_features = int(getattr(self.inner, "n_active_nonlinear", 0))
        self.certificate = float(getattr(self.inner, "certificate_", np.nan))
        return self

    # -- coordinate maps ----------------------------------------------------

    def encode(self, S_phys: np.ndarray) -> np.ndarray:
        N = self.normalizer.transform(np.asarray(S_phys))
        return np.asarray(self.inner.encode(N))

    def _normalized(self, S_phys: np.ndarray) -> np.ndarray:
        return np.asarray(self.normalizer.transform(np.asarray(S_phys)))

    def decode(self, latent: np.ndarray) -> np.ndarray:
        import jax.numpy as jnp
        N_hat = self.inner.decode(jnp.asarray(np.asarray(latent, dtype=float)))
        return np.asarray(self.normalizer.inverse_transform(N_hat))

    def features(self, Shat: np.ndarray) -> Optional[np.ndarray]:
        return rom.eval_features_matrix(self.feature_fn, Shat)

    # -- Operator Inference from one trajectory -----------------------------

    def learn_plain(self, S_block: np.ndarray, dt: float) -> Dict[str, np.ndarray]:
        """Plain latent OpInf operators ``(c, A, N)`` from one trajectory."""
        Shat = self.encode(S_block)
        dShat = fbct4(Shat, dt)
        P_nl = self.features(Shat)
        return rom.infer_operators(Shat, dShat, P_nl, **self.lam)

    def learn_rpg(self, S_block: np.ndarray, dt: float) -> Dict[str, Dict[str, np.ndarray]]:
        """Geometric (RPG) operators: ``a = V^T f`` and ``b = Vbar^T f``.

        Returns ``{"a": a_ops, "b": b_ops}``; ``b`` is absent for POD (no
        manifold), where the RPG model reduces to the plain linear ROM.
        """
        Shat = self.encode(S_block)
        dShat = fbct4(Shat, dt)
        P_nl = self.features(Shat)
        a_ops = rom.infer_operators(Shat, dShat, P_nl, **self.lam)
        if not self.has_manifold:
            return {"a": a_ops}
        q = self.Vbar.T @ self._normalized(S_block)     # (m, N) lifting coords
        dq = fbct4(q, dt)                               # Vbar^T Ndot
        b_ops = rom.infer_operators(Shat, dq, P_nl, **self.lam)
        return {"a": a_ops, "b": b_ops}

    # -- Simulate + decode --------------------------------------------------

    def simulate_plain(self, ops: Dict[str, np.ndarray], S_truth: np.ndarray,
                       dt: float, *, method: str = "rk4") -> np.ndarray:
        s0 = self.encode(S_truth[:, :1])[:, 0]
        n_steps = S_truth.shape[1] - 1
        latent = rom.simulate(ops, self.feature_fn, s0, n_steps, dt, method=method)
        return self.decode(latent)

    def simulate_rpg(self, rpg_ops: Dict[str, Dict[str, np.ndarray]],
                     S_truth: np.ndarray, dt: float) -> np.ndarray:
        s0 = self.encode(S_truth[:, :1])[:, 0]
        n_steps = S_truth.shape[1] - 1
        if not self.has_manifold:                       # POD: linear ROM
            latent = rom.simulate(rpg_ops["a"], None, s0, n_steps, dt, method="rk4")
        else:
            latent = rom.simulate_rpg(
                rpg_ops["a"], rpg_ops["b"], self.feature_jac_fn,
                self.G_lift, s0, n_steps, dt)
        return self.decode(latent)
