"""Elementwise spline interpolation of parametric operators.

Operator Inference learns one reduced operator set per training parameter.  To
evaluate the reduced model at a new parameter value we interpolate **each
operator entry** across the training parameters, exactly as in the Julia
reference ``interpolate_matrix_elements``.  Cubic (natural), quartic, and
quintic splines are supported; the cubic natural spline is the default.

Two regimes are separated cleanly:

* **Interpolation** (query strictly inside the knot range): the natural spline
  of the requested order.
* **Extrapolation** (query beyond the knot range): a per-entry *affine* (degree
  one) least-squares fit in the parameter.  For a linear PDE the reduced
  operators are provably affine in the physical parameter (see the note
  ``notes/opinf_opm.tex``), so an affine continuation is the principled choice
  rather than letting a high-order spline diverge past its last knot.

The parameter nodes ``z`` must be strictly increasing.  All routines are pure
NumPy and act on real matrices of identical shape.
"""

from __future__ import annotations

from typing import Dict, List, Sequence

import numpy as np

_SUPPORTED_ORDERS = (3, 4, 5)


# ---------------------------------------------------------------------------
# Cubic natural spline (second-derivative form; matches the Julia reference)
# ---------------------------------------------------------------------------


def cubic_spline_second_derivs(z: np.ndarray, f: np.ndarray) -> np.ndarray:
    """Natural cubic-spline second derivatives ``M`` at the knots."""
    z = np.asarray(z, dtype=float)
    f = np.asarray(f, dtype=float)
    n = z.shape[0] - 1
    h = np.diff(z)
    A = np.zeros((n + 1, n + 1))
    b = np.zeros(n + 1)
    A[0, 0] = 1.0
    A[n, n] = 1.0
    for i in range(1, n):
        A[i, i - 1] = h[i - 1]
        A[i, i] = 2.0 * (h[i - 1] + h[i])
        A[i, i + 1] = h[i]
        b[i] = 6.0 * ((f[i + 1] - f[i]) / h[i] - (f[i] - f[i - 1]) / h[i - 1])
    return np.linalg.solve(A, b)


def cubic_spline_eval(z: np.ndarray, f: np.ndarray, M: np.ndarray,
                      zq: float) -> float:
    """Evaluate the natural cubic spline at an interior query ``zq``."""
    z = np.asarray(z, dtype=float)
    i = int(np.searchsorted(z, zq, side="right") - 1)
    i = min(max(i, 0), z.shape[0] - 2)
    h = z[i + 1] - z[i]
    t1 = M[i] * (z[i + 1] - zq) ** 3 / (6.0 * h)
    t2 = M[i + 1] * (zq - z[i]) ** 3 / (6.0 * h)
    t3 = (f[i] - M[i] * h * h / 6.0) * (z[i + 1] - zq) / h
    t4 = (f[i + 1] - M[i + 1] * h * h / 6.0) * (zq - z[i]) / h
    return float(t1 + t2 + t3 + t4)


# ---------------------------------------------------------------------------
# Quartic / quintic splines (full piecewise-coefficient systems)
# ---------------------------------------------------------------------------


def quartic_spline_coefficients(x: np.ndarray, y: np.ndarray) -> np.ndarray:
    """Quartic-spline coefficients (5 per interval) with natural-type ends."""
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    n = x.shape[0] - 1
    h = np.diff(x)
    A = np.zeros((5 * n, 5 * n))
    b = np.zeros(5 * n)
    eq = 0
    for i in range(n):
        idx = 5 * i
        A[eq, idx] = 1.0
        b[eq] = y[i]
        eq += 1
        A[eq, idx:idx + 5] = [1.0, h[i], h[i] ** 2, h[i] ** 3, h[i] ** 4]
        b[eq] = y[i + 1]
        eq += 1
    for i in range(1, n):
        ip = 5 * (i - 1)
        ic = 5 * i
        hp = h[i - 1]
        A[eq, ip + 1:ip + 5] = [1.0, 2 * hp, 3 * hp ** 2, 4 * hp ** 3]
        A[eq, ic + 1] = -1.0
        eq += 1
    for i in range(1, n):
        ip = 5 * (i - 1)
        ic = 5 * i
        hp = h[i - 1]
        A[eq, ip + 2:ip + 5] = [2.0, 6 * hp, 12 * hp ** 2]
        A[eq, ic + 2] = -2.0
        eq += 1
    for i in range(1, n):
        ip = 5 * (i - 1)
        ic = 5 * i
        hp = h[i - 1]
        A[eq, ip + 3:ip + 5] = [6.0, 24 * hp]
        A[eq, ic + 3] = -6.0
        eq += 1
    A[eq, 2] = 2.0        # second derivative at first knot
    eq += 1
    A[eq, 3] = 6.0        # third derivative at first knot
    eq += 1
    il = 5 * (n - 1)
    hl = h[-1]
    A[eq, il + 2:il + 5] = [2.0, 6 * hl, 12 * hl ** 2]
    eq += 1
    if eq != 5 * n:
        raise RuntimeError("quartic spline: equation/unknown mismatch.")
    return np.linalg.solve(A, b)


def quintic_spline_coefficients(z: np.ndarray, f: np.ndarray) -> np.ndarray:
    """Quintic-spline coefficients (6 per interval) with natural-type ends."""
    z = np.asarray(z, dtype=float)
    f = np.asarray(f, dtype=float)
    n = z.shape[0] - 1
    h = np.diff(z)
    A = np.zeros((6 * n, 6 * n))
    b = np.zeros(6 * n)
    for i in range(n):
        idx = 6 * i
        A[2 * i, idx] = 1.0
        A[2 * i + 1, idx:idx + 6] = [
            1.0, h[i], h[i] ** 2, h[i] ** 3, h[i] ** 4, h[i] ** 5]
        b[2 * i] = f[i]
        b[2 * i + 1] = f[i + 1]
    for i in range(1, n):
        row = 2 * n + 4 * (i - 1)
        hm = h[i - 1]
        ip = 6 * (i - 1)
        ic = 6 * i
        A[row, ip:ip + 6] = [0.0, 1.0, 2 * hm, 3 * hm ** 2,
                             4 * hm ** 3, 5 * hm ** 4]
        A[row, ic + 1] = -1.0
        A[row + 1, ip:ip + 6] = [0.0, 0.0, 2.0, 6 * hm,
                                 12 * hm ** 2, 20 * hm ** 3]
        A[row + 1, ic + 2] = -2.0
        A[row + 2, ip:ip + 6] = [0.0, 0.0, 0.0, 6.0, 24 * hm, 60 * hm ** 2]
        A[row + 2, ic + 3] = -6.0
        A[row + 3, ip:ip + 6] = [0.0, 0.0, 0.0, 0.0, 24.0, 120 * hm]
        A[row + 3, ic + 4] = -24.0
    A[6 * n - 4, 1] = 1.0          # first derivative at z[0]
    A[6 * n - 3, 2] = 2.0          # second derivative at z[0]
    hn = h[-1]
    il = 6 * (n - 1)
    A[6 * n - 2, il + 1:il + 6] = [1.0, 2 * hn, 3 * hn ** 2,
                                   4 * hn ** 3, 5 * hn ** 4]
    A[6 * n - 1, il + 2:il + 6] = [2.0, 6 * hn, 12 * hn ** 2, 20 * hn ** 3]
    return np.linalg.solve(A, b)


def _poly_spline_eval(z: np.ndarray, coeffs: np.ndarray, zq: float,
                      stride: int) -> float:
    """Evaluate a piecewise-polynomial spline (quartic/quintic) at ``zq``."""
    z = np.asarray(z, dtype=float)
    i = int(np.searchsorted(z, zq, side="right") - 1)
    i = min(max(i, 0), z.shape[0] - 2)
    hh = zq - z[i]
    c = coeffs[stride * i: stride * i + stride]
    return float(sum(c[p] * hh ** p for p in range(stride)))


# ---------------------------------------------------------------------------
# Scalar elementwise interpolation (interior) of a stack of matrices
# ---------------------------------------------------------------------------


def interpolate_matrix_elements(z: Sequence[float], matrices: Sequence[np.ndarray],
                                zq: float, order: int = 3) -> np.ndarray:
    """Interpolate every entry of a set of matrices at ``zq`` (interior query).

    ``matrices[k]`` is the matrix at parameter ``z[k]``; all share one shape.
    Mirrors the Julia ``interpolate_matrix_elements``.

    Arguments
    ---------
    z : (P,) strictly increasing parameter nodes.
    matrices : list of (a, b) real matrices, one per node.
    zq : query parameter, expected within ``[z[0], z[-1]]``.
    order : 3 (cubic natural), 4 (quartic), or 5 (quintic).
    """
    if order not in _SUPPORTED_ORDERS:
        raise ValueError(f"order must be one of {_SUPPORTED_ORDERS}; got {order}.")
    z = np.asarray(z, dtype=float)
    stack = np.stack([np.asarray(m, dtype=float) for m in matrices], axis=0)
    P, a, b = stack.shape
    out = np.empty((a, b))
    for i in range(a):
        for j in range(b):
            fvals = stack[:, i, j]
            if order == 3:
                M = cubic_spline_second_derivs(z, fvals)
                out[i, j] = cubic_spline_eval(z, fvals, M, zq)
            elif order == 4:
                c = quartic_spline_coefficients(z, fvals)
                out[i, j] = _poly_spline_eval(z, c, zq, 5)
            else:
                c = quintic_spline_coefficients(z, fvals)
                out[i, j] = _poly_spline_eval(z, c, zq, 6)
    return out


# ---------------------------------------------------------------------------
# Affine (degree-1) elementwise extrapolation
# ---------------------------------------------------------------------------


def affine_extrapolate_matrix_elements(z: Sequence[float],
                                       matrices: Sequence[np.ndarray],
                                       zq: float) -> np.ndarray:
    """Per-entry least-squares affine fit ``a*z + b`` evaluated at ``zq``.

    Uses all nodes, so it is robust and exact whenever the entries are affine
    in the parameter (the linear-PDE case).  Suitable for queries outside the
    knot range where a high-order spline would diverge.
    """
    z = np.asarray(z, dtype=float)
    stack = np.stack([np.asarray(m, dtype=float) for m in matrices], axis=0)
    P, a, b = stack.shape
    # least-squares slope/intercept per entry in one solve
    zbar = z.mean()
    zc = z - zbar
    denom = float(np.dot(zc, zc))
    F = stack.reshape(P, a * b)
    fbar = F.mean(axis=0)
    slope = (zc[:, None] * (F - fbar[None, :])).sum(axis=0) / denom
    val = fbar + slope * (zq - zbar)
    return val.reshape(a, b)


# ---------------------------------------------------------------------------
# Operator-dictionary convenience wrappers
# ---------------------------------------------------------------------------


def interp_operator_dict(z: Sequence[float],
                         op_dicts: Sequence[Dict[str, np.ndarray]],
                         zq: float, *, order: int = 3,
                         keys: Sequence[str] | None = None
                         ) -> Dict[str, np.ndarray]:
    """Interpolate a per-parameter operator dictionary at an interior ``zq``.

    ``op_dicts[k]`` maps an operator name (e.g. ``"c"``, ``"A"``, ``"N"``) to
    the operator at parameter ``z[k]``.  Returns the interpolated dictionary.
    """
    keys = list(op_dicts[0].keys()) if keys is None else list(keys)
    return {
        name: interpolate_matrix_elements(
            z, [od[name] for od in op_dicts], zq, order=order)
        for name in keys
    }


def extrap_operator_dict(z: Sequence[float],
                         op_dicts: Sequence[Dict[str, np.ndarray]],
                         zq: float, *,
                         keys: Sequence[str] | None = None
                         ) -> Dict[str, np.ndarray]:
    """Affine-extrapolate a per-parameter operator dictionary at ``zq``."""
    keys = list(op_dicts[0].keys()) if keys is None else list(keys)
    return {
        name: affine_extrapolate_matrix_elements(
            z, [od[name] for od in op_dicts], zq)
        for name in keys
    }


def nearest_operator_dict(z: Sequence[float],
                          op_dicts: Sequence[Dict[str, np.ndarray]],
                          zq: float, *,
                          keys: Sequence[str] | None = None
                          ) -> Dict[str, np.ndarray]:
    """Nearest-parameter operator dictionary (naive extrapolation fallback)."""
    z = np.asarray(z, dtype=float)
    k = int(np.argmin(np.abs(z - zq)))
    keys = list(op_dicts[0].keys()) if keys is None else list(keys)
    return {name: np.asarray(op_dicts[k][name], dtype=float) for name in keys}
