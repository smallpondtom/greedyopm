"""Fourth-order finite-difference time derivatives on a uniform grid.

The reduced-coordinate time derivatives ``Shat_dot`` that Operator Inference
regresses against are estimated non-intrusively from the encoded coordinate
trajectories.  A single scheme is used, the *forward-backward-central* stencil
``FBCT4`` of the Julia reference (``RPGOpInf.jl/scripts/utils.jl``):

* fourth-order **forward** differences at the first two samples,
* fourth-order **central** differences in the interior,
* fourth-order **backward** differences at the last two samples.

Every column of the trajectory receives a fourth-order estimate, so the number
of derivative samples equals the number of state samples (no snapshots are
dropped).  The trajectory must have at least five time samples.

All derivatives are taken **within a single trajectory** (one parameter value);
a concatenated multi-parameter snapshot matrix must be differentiated
trajectory by trajectory, never across a parameter boundary -- see
:func:`fbct4_blocked`.
"""

from __future__ import annotations

import numpy as np

_MIN_SAMPLES = 5


def fbct4(X: np.ndarray, dt: float) -> np.ndarray:
    """Fourth-order FBCT time derivative of a single trajectory.

    Arguments
    ---------
    X : (d, N)
        State (or reduced-coordinate) trajectory, columns ordered in time on a
        uniform grid of spacing ``dt``.  ``N >= 5`` is required.
    dt : float
        Uniform time-step.

    Returns
    -------
    dX : (d, N)
        Column ``j`` is the fourth-order estimate of ``dX/dt`` at time index
        ``j``; forward at ``j in {0, 1}``, central for ``2 <= j <= N-3``,
        backward at ``j in {N-2, N-1}``.
    """
    X = np.asarray(X, dtype=float)
    if X.ndim != 2:
        raise ValueError(f"X must be 2D (d, N); got shape {X.shape}.")
    d, N = X.shape
    if N < _MIN_SAMPLES:
        raise ValueError(
            f"FBCT4 needs at least {_MIN_SAMPLES} time samples; got N={N}."
        )
    dX = np.empty_like(X)
    twelve_dt = 12.0 * dt

    # -- first two points: fourth-order forward stencils --------------------
    dX[:, 0] = (
        -25.0 * X[:, 0] + 48.0 * X[:, 1] - 36.0 * X[:, 2]
        + 16.0 * X[:, 3] - 3.0 * X[:, 4]
    ) / twelve_dt
    dX[:, 1] = (
        -3.0 * X[:, 0] - 10.0 * X[:, 1] + 18.0 * X[:, 2]
        - 6.0 * X[:, 3] + 1.0 * X[:, 4]
    ) / twelve_dt

    # -- interior: fourth-order central stencil -----------------------------
    # dX[:, j] = (X[j-2] - 8 X[j-1] + 8 X[j+1] - X[j+2]) / (12 dt), 2<=j<=N-3
    dX[:, 2:N - 2] = (
        X[:, 0:N - 4] - 8.0 * X[:, 1:N - 3]
        + 8.0 * X[:, 3:N - 1] - X[:, 4:N]
    ) / twelve_dt

    # -- last two points: fourth-order backward stencils --------------------
    dX[:, N - 2] = (
        -1.0 * X[:, N - 5] + 6.0 * X[:, N - 4] - 18.0 * X[:, N - 3]
        + 10.0 * X[:, N - 2] + 3.0 * X[:, N - 1]
    ) / twelve_dt
    dX[:, N - 1] = (
        3.0 * X[:, N - 5] - 16.0 * X[:, N - 4] + 36.0 * X[:, N - 3]
        - 48.0 * X[:, N - 2] + 25.0 * X[:, N - 1]
    ) / twelve_dt
    return dX


def fbct4_blocked(X: np.ndarray, dt: float, n_per: int) -> np.ndarray:
    """FBCT4 derivative of several equal-length trajectories laid side by side.

    ``X`` is a ``(d, n_traj * n_per)`` matrix whose columns are ``n_traj``
    consecutive trajectories of ``n_per`` samples each (the layout produced by
    concatenating per-parameter snapshot blocks).  Each block is differentiated
    independently so the stencils never straddle a parameter boundary.

    Arguments
    ---------
    X : (d, n_traj * n_per)
    dt : float
    n_per : int
        Samples per trajectory.

    Returns
    -------
    dX : (d, n_traj * n_per)
    """
    X = np.asarray(X, dtype=float)
    d, k = X.shape
    if k % n_per != 0:
        raise ValueError(
            f"Column count {k} is not a multiple of n_per={n_per}."
        )
    n_traj = k // n_per
    dX = np.empty_like(X)
    for b in range(n_traj):
        sl = slice(b * n_per, (b + 1) * n_per)
        dX[:, sl] = fbct4(X[:, sl], dt)
    return dX
