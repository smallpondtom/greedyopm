# OpInf + Greedy-OPM reduced-order models (linear advection-diffusion)

Non-intrusive reduced-order models built on the Greedy-OPM manifold by Operator
Inference, in the spirit of the quadratic-manifold OpInf of Geelen, Wright &
Willcox (2023), extended to the orthogonal-polynomial manifold and to a
budget-stabilized geometric (RPG) reduced model. The manifold is trained jointly
on several training wave speeds; one reduced operator set is learned per speed;
a query speed is served by elementwise interpolation (in range) or affine
extrapolation (out of range) of the operators. Theory: `paper/.../notes/opinf_opm.tex`.

## What is compared

For each reduced dimension `r` the manifold is fit, per-speed operators are
learned by Operator Inference with fourth-order finite-difference reduced
velocities, the reduced model is simulated (RK4) and decoded, and the relative
Frobenius state error is reported at the training speeds, an interpolated speed,
and an extrapolated speed.

Two reduced-model families:

- **Plain latent OpInf** (`kind="plain"`): `shat' = c + A shat + N p(shat)`. The
  requested Geelen-style baseline. For a polynomial manifold on this advection
  problem it is dynamically unstable away from a tight budget, because the latent
  ODE ignores the manifold metric and the polynomial features blow up once the
  latent drifts past the certified collar.
- **RPG-OpInf** (`kind="rpg"`, the main method): the geometric manifold-Galerkin
  model `shat' = M^{-1}(a + Jp^T b)` with mass matrix
  `M = I + Jp^T Vbar^T Vbar Jp`. The Lipschitz budget bounds `cond(M) <= L^2`, so
  a budget selected for ROM stability keeps the simulated latent bounded.

Manifolds: `POD` (linear ROM baseline), `Greedy-CM` (cubic monomial),
`Greedy-OPM (p=2)`, `Greedy-OPM (p=3)`.

## Key findings (see the theory note and `*_report.json`)

- Manifold **reconstruction** is excellent (~1e-4); the difficulty is entirely
  in carrying dynamics.
- The **plain latent ROM is unstable** for the polynomial manifolds unless the
  budget is tightened; the **cubic monomial manifold (Greedy-CM) is
  catastrophically unstable** as a ROM at every `r` (its features are neither
  orthonormal nor budgeted).
- The **RPG ROM beats POD at low `r`** (where the advection problem places POD
  against its Kolmogorov-width barrier) on the training and interpolated speeds,
  in the gentle regime, at a budget selected for stability. **Extrapolation** past
  the training speed range is the fragile leg.
- The **budget study** figure shows the stability-accuracy trade-off directly:
  the interp/extrap ROM errors dip to a minimum then jump to the divergence cap,
  and `L*` sits at that minimum.

## Files

| file | purpose |
|---|---|
| `problem_opinf.py` | per-parameter trajectories; regimes `gentle` / `resolved` / `reconstruction` |
| `findiff.py` | fourth-order FBCT finite-difference reduced velocities |
| `spline.py` | cubic/quartic/quintic elementwise operator interpolation + affine extrapolation (port of the Julia `interpolate_matrix_elements`) |
| `rom.py` | OpInf regression; plain and RPG simulators; feature + Jacobian maps |
| `opinf_methods.py` | `ManifoldROM` adapter (fit manifold, learn operators, simulate, decode) |
| `parametric.py` | per-parameter operator learning, interp/extrap, ROM error evaluation |
| `budget_select_rom.py` | ROM-targeted Lipschitz-budget selection |
| `run_opinf.py` | driver (phases `budget`, `sweep`, `plots`, `report`; resumable JSON) |
| `plots_opinf.py` | error-vs-r, budget study, space-time panels |

## Reproduce

```bash
cd experiments/lin_adv_diff/opinf
python run_opinf.py all gentle      # clean regime (headline result)
python run_opinf.py all resolved    # harder, stiffer regime (extrapolation fragile)
```

Checkpoints and figures are written to `plots/` and are resumable. The gentle
run takes a few minutes (most of it the two budget selections). The reduced model
uses the manifold's `set_budget` to sweep budgets cheaply.

## Notes / caveats

- The manifold is fit with a ROM-appropriate certificate collar `delta=1.0`
  (larger than the reconstruction experiment's 0.1), so the certificate covers
  the region the simulated latent visits.
- Reduced velocities are estimated from the encoded trajectory by FBCT4, giving
  one velocity sample per state sample (no snapshots dropped).
- The initial condition is parameter-independent, so the parametric variation is
  carried entirely by the operators.
