"""ROM-targeted Lipschitz-budget selection.

Unlike the reconstruction experiment (which tunes ``L`` on reconstruction
error), the OpInf ROM needs a budget that keeps the *simulated* latent stable
while retaining enough manifold capacity to beat POD.  The objective is the
geometric mean of the interpolation and extrapolation ROM relative errors, with
a large penalty for a diverged rollout, minimized over a budget grid that is
evaluated cheaply via :meth:`ManifoldROM.set_budget` on a single reference fit
(the greedy modes are kept, only the lifting is recalibrated).

A tight budget over-damps the manifold toward POD; a loose budget lets the
latent drift past the certified collar and the polynomial decode diverges.  The
minimizer is the stable-and-accurate compromise.
"""

from __future__ import annotations

import numpy as np

import parametric

PENALTY = 1.0e3            # objective value assigned to a diverged / nonfinite ROM
L_GRID_LO = 3.0
L_GRID_HI = 3.0e3
N_COARSE = 12
N_REFINE = 9


def _objective(mrom, data) -> tuple:
    rec = parametric.evaluate(mrom, data, kind="rpg")
    ei, ee = rec["interp"], rec["extrap"]

    def safe(e):
        return e if np.isfinite(e) and e < PENALTY else PENALTY
    ei, ee = safe(ei), safe(ee)
    return float(np.sqrt(ei * ee)), rec["interp"], rec["extrap"], rec["n_features"]


def select_budget_rom(mrom, data, *, log=print) -> dict:
    """Select ``L*`` for a fitted :class:`ManifoldROM` by ROM-error minimization.

    ``mrom`` must already be fit (at a loose reference budget); this sweeps the
    budget by ``set_budget`` and returns the study record with ``L_star`` and
    the full curve.
    """
    curve = []

    def obj_at(L):
        mrom.set_budget(float(L))
        o, ei, ee, nf = _objective(mrom, data)
        curve.append(dict(L=float(L), objective=float(o), interp=float(ei),
                          extrap=float(ee), n_features=int(nf),
                          certificate=float(mrom.certificate)))
        return o

    grid = np.geomspace(L_GRID_LO, L_GRID_HI, N_COARSE)
    objs = [obj_at(L) for L in grid]
    i = int(np.argmin(objs))
    L_star, best = float(grid[i]), objs[i]
    lo = float(grid[max(i - 1, 0)])
    hi = float(grid[min(i + 1, N_COARSE - 1)])
    log(f"    [Lsel] coarse L*={L_star:.3g} obj={best:.3e} "
        f"bracket=[{lo:.3g},{hi:.3g}]", flush=True)

    for L in np.linspace(lo, hi, N_REFINE):
        o = obj_at(L)
        if o < best:
            best, L_star = o, float(L)
    log(f"    [Lsel] refined L*={L_star:.3g} obj={best:.3e}", flush=True)

    mrom.set_budget(L_star)
    return dict(L_star=float(L_star), best_objective=float(best),
                curve=sorted(curve, key=lambda d: d["L"]))
