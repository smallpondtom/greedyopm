"""Parametric operator learning, interpolation, and ROM error evaluation.

One reduced operator set is learned per training wave speed.  A query speed is
served by **elementwise cubic-spline interpolation** of the operators inside the
training range and by **affine extrapolation** beyond it (for a linear PDE the
reduced operators are affine in the speed, so the affine continuation is exact
in the limit).  Two ROM families are supported:

* ``"plain"`` -- the latent OpInf model ``shat_dot = c + A shat + N p(shat)``.
* ``"rpg"``   -- the geometric manifold-Galerkin model with operator pair
  ``a = V^T f`` and ``b = Vbar^T f``.

The reported quantity is the relative Frobenius state error of the decoded ROM
trajectory against the exact snapshots, per training speed and for the interp /
extrap speeds.
"""

from __future__ import annotations

from typing import Dict, List

import numpy as np

import spline
from rom import relative_state_error


# ---------------------------------------------------------------------------
# Per-parameter operator learning
# ---------------------------------------------------------------------------


def learn_per_param(mrom, blocks: List[np.ndarray], dt: float,
                    kind: str = "rpg") -> List:
    """Learn one operator set per training trajectory block."""
    if kind == "plain":
        return [mrom.learn_plain(blk, dt) for blk in blocks]
    if kind == "rpg":
        return [mrom.learn_rpg(blk, dt) for blk in blocks]
    raise ValueError(f"Unknown ROM kind {kind!r}.")


# ---------------------------------------------------------------------------
# Operator interpolation / extrapolation (handles both ROM families)
# ---------------------------------------------------------------------------


def _interp(speeds, op_list, cq, order):
    if "a" in op_list[0]:                              # rpg pair
        out = {"a": spline.interp_operator_dict(speeds, [d["a"] for d in op_list], cq, order=order)}
        if "b" in op_list[0]:
            out["b"] = spline.interp_operator_dict(speeds, [d["b"] for d in op_list], cq, order=order)
        return out
    return spline.interp_operator_dict(speeds, op_list, cq, order=order)


def _extrap(speeds, op_list, cq, mode):
    fn = spline.extrap_operator_dict if mode == "affine" else spline.nearest_operator_dict
    if "a" in op_list[0]:
        out = {"a": fn(speeds, [d["a"] for d in op_list], cq)}
        if "b" in op_list[0]:
            out["b"] = fn(speeds, [d["b"] for d in op_list], cq)
        return out
    return fn(speeds, op_list, cq)


def _simulate(mrom, ops, S_truth, dt, kind):
    if kind == "plain":
        return mrom.simulate_plain(ops, S_truth, dt)
    return mrom.simulate_rpg(ops, S_truth, dt)


# ---------------------------------------------------------------------------
# Full parametric evaluation
# ---------------------------------------------------------------------------


def evaluate(mrom, data: Dict, kind: str = "rpg", *, order: int = 3,
             extrap_mode: str = "affine") -> Dict:
    """Learn per-speed operators and score train / interp / extrap ROM errors.

    Returns a record with per-speed training errors, their median, the
    interpolation error (spline operators), and the extrapolation error (affine
    operators), all as relative Frobenius state errors.
    """
    dt = data["dt"]
    speeds = data["train"]["speeds"]
    blocks = data["train"]["blocks"]
    op_list = learn_per_param(mrom, blocks, dt, kind)

    train_errs = [
        relative_state_error(blk, _simulate(mrom, ops, blk, dt, kind))
        for blk, ops in zip(blocks, op_list)
    ]

    ops_i = _interp(speeds, op_list, data["interp"]["c"], order)
    err_i = relative_state_error(
        data["interp"]["S"], _simulate(mrom, ops_i, data["interp"]["S"], dt, kind))

    ops_e = _extrap(speeds, op_list, data["extrap"]["c"], extrap_mode)
    err_e = relative_state_error(
        data["extrap"]["S"], _simulate(mrom, ops_e, data["extrap"]["S"], dt, kind))

    return dict(
        train_per_speed=[float(e) for e in train_errs],
        train_median=float(np.median(train_errs)),
        interp=float(err_i),
        extrap=float(err_e),
        n_features=int(mrom.n_features),
        certificate=float(mrom.certificate),
    )


def decoded_trajectories(mrom, data: Dict, kind: str = "rpg", *,
                         order: int = 3, extrap_mode: str = "affine") -> Dict:
    """Return decoded ROM trajectories for the interp and extrap speeds (plots)."""
    dt = data["dt"]
    speeds = data["train"]["speeds"]
    op_list = learn_per_param(mrom, data["train"]["blocks"], dt, kind)
    ops_i = _interp(speeds, op_list, data["interp"]["c"], order)
    ops_e = _extrap(speeds, op_list, data["extrap"]["c"], extrap_mode)
    return dict(
        interp=np.asarray(_simulate(mrom, ops_i, data["interp"]["S"], dt, kind)),
        extrap=np.asarray(_simulate(mrom, ops_e, data["extrap"]["S"], dt, kind)),
    )
