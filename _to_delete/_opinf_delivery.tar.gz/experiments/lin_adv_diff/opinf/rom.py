"""Operator Inference on an orthogonal-polynomial manifold.

The reduced model evolves the linear encoder coordinates
``shat = V^T (s - s_ref)`` and closes with the *same* nonlinear polynomial
features the manifold uses to lift,

    d/dt shat = c_hat + A_hat shat + N_hat p(shat) ,

where ``p(shat)`` is the active orthogonal-polynomial feature block of the
Greedy-OPM manifold (or the full monomial shell of a monomial baseline, or
empty for a purely linear POD manifold).  The operators are learned
non-intrusively by regressing fourth-order finite-difference estimates of the
projected time derivative onto the feature dictionary; because the nonlinear
features are empirically orthonormal the regression is well conditioned, in
contrast to the ill-conditioned Kronecker-product data matrix of monomial
Operator Inference.

For a linear full-order model (the advection-diffusion equation) this is the
*exact* structure of the reduced dynamics of an on-manifold state, and the
learned operators are affine in the physical parameter -- the property the
parametric interpolation in :mod:`spline` exploits.

The decoded state is ``Gamma(shat) = s_ref + V shat + Vbar p(shat)``, so the
manifold's Lipschitz certificate bounds how far the reconstruction can move
when the simulated latent state drifts off the training trajectory.
"""

from __future__ import annotations

from functools import partial
from typing import Callable, Dict, Sequence

import jax
import jax.numpy as jnp
import numpy as np

FeatureFn = Callable[[jnp.ndarray], jnp.ndarray]  # (r,) -> (q,) nonlinear feats


# ===========================================================================
# Operator Inference regression
# ===========================================================================


def infer_operators(
    Shat: np.ndarray,
    dShat: np.ndarray,
    P_nl: np.ndarray | None,
    *,
    lam_lin: float = 0.0,
    lam_nl: float = 0.0,
    lam_const: float = 0.0,
) -> Dict[str, np.ndarray]:
    """Least-squares fit of ``dShat = c + A Shat + N P_nl`` (order-wise ridge).

    Arguments
    ---------
    Shat : (r, k)   reduced coordinates.
    dShat : (r, k)  reduced time derivatives (FBCT4 estimate).
    P_nl : (q, k) or None
        Active nonlinear feature values on the same coordinates; ``None`` or an
        empty array yields a linear (constant + linear) model.
    lam_lin, lam_nl, lam_const : float
        Tikhonov weights for the linear, nonlinear, and constant blocks.

    Returns
    -------
    ops : dict with keys ``"c"`` (r,1), ``"A"`` (r,r) and, when nonlinear
    features are present, ``"N"`` (r,q).
    """
    Shat = np.asarray(Shat, dtype=float)
    dShat = np.asarray(dShat, dtype=float)
    r, k = Shat.shape
    r_out = dShat.shape[0]           # target row count (r, or m for a lifting map)
    blocks = [np.ones((1, k)), Shat]
    reg = [lam_const, *([lam_lin] * r)]
    has_nl = P_nl is not None and np.asarray(P_nl).size > 0
    if has_nl:
        P_nl = np.asarray(P_nl, dtype=float)
        q = P_nl.shape[0]
        blocks.append(P_nl)
        reg += [lam_nl] * q
    D = np.vstack(blocks).T                       # (k, d)
    d = D.shape[1]
    Reg = np.diag(np.sqrt(np.asarray(reg)))
    # augmented Tikhonov least squares  min ||D O^T - dShat^T||^2 + ||Reg O^T||^2
    D_aug = np.vstack([D, Reg])                   # (k + d, d)
    R_aug = np.vstack([dShat.T, np.zeros((d, r_out))])
    O_T, *_ = np.linalg.lstsq(D_aug, R_aug, rcond=None)
    O = O_T.T                                     # (r, d)
    ops = {"c": O[:, 0:1], "A": O[:, 1:1 + r]}
    if has_nl:
        ops["N"] = O[:, 1 + r:]
    return ops


def relative_fit_residual(Shat, dShat, P_nl, ops) -> float:
    """Relative training residual of the inferred ROM RHS (a diagnostic)."""
    Shat = np.asarray(Shat); dShat = np.asarray(dShat)
    pred = ops["c"] + ops["A"] @ Shat
    if "N" in ops and P_nl is not None and np.asarray(P_nl).size > 0:
        pred = pred + ops["N"] @ np.asarray(P_nl)
    return float(np.linalg.norm(dShat - pred) / (np.linalg.norm(dShat) + 1e-300))


# ===========================================================================
# ROM right-hand side and time integration (JAX)
# ===========================================================================


def _make_rhs(ops: Dict[str, jnp.ndarray], feature_fn: FeatureFn | None):
    c = ops["c"].reshape(-1)
    A = ops["A"]
    if "N" in ops and feature_fn is not None:
        N = ops["N"]

        def rhs(s):
            return c + A @ s + N @ feature_fn(s)
    else:
        def rhs(s):
            return c + A @ s
    return rhs


@partial(jax.jit, static_argnames=("rhs", "n_steps", "method"))
def _rollout(rhs, s0, dt, n_steps, method):
    """Integrate ``s' = rhs(s)`` for ``n_steps`` steps from ``s0``.

    ``method`` is ``"rk4"`` or ``"explicit"``.  Semi-implicit / CNAB steppers
    that need a factorized linear operator are handled in :func:`simulate`.
    """
    def rk4_step(s, _):
        k1 = rhs(s)
        k2 = rhs(s + 0.5 * dt * k1)
        k3 = rhs(s + 0.5 * dt * k2)
        k4 = rhs(s + dt * k3)
        s_next = s + (dt / 6.0) * (k1 + 2 * k2 + 2 * k3 + k4)
        return s_next, s_next

    def euler_step(s, _):
        s_next = s + dt * rhs(s)
        return s_next, s_next

    step = rk4_step if method == "rk4" else euler_step
    _, traj = jax.lax.scan(step, s0, None, length=n_steps)
    return traj  # (n_steps, r)


def _rollout_semi_implicit(ops, feature_fn, s0, dt, n_steps, *, theta=1.0):
    """Linearly-implicit rollout: (I - theta dt A) s+ = s + dt (c + N p(s)).

    ``theta = 1`` is backward-Euler on the linear part (L-stable, dissipative);
    ``theta = 0.5`` is the Crank-Nicolson variant used by the CNAB stepper.
    The nonlinear term is treated explicitly.  The linear factor is constant
    along a rollout, so it is factorized once.
    """
    r = s0.shape[0]
    A = ops["A"]
    c = ops["c"].reshape(-1)
    lhs = jnp.eye(r) - theta * dt * A
    lu, piv = jax.scipy.linalg.lu_factor(lhs)
    rhs_lin = (1.0 - theta) * dt * A
    has_nl = "N" in ops and feature_fn is not None
    N = ops["N"] if has_nl else None

    def step(s, _):
        expl = s + rhs_lin @ s + dt * c
        if has_nl:
            expl = expl + dt * (N @ feature_fn(s))
        s_next = jax.scipy.linalg.lu_solve((lu, piv), expl)
        return s_next, s_next

    _, traj = jax.lax.scan(step, s0, None, length=n_steps)
    return traj


def _rpg_rollout(a_ops, b_ops, feat_jac_fn, G_lift, s0, dt, n_steps):
    """Geometric manifold-Galerkin (RPG) rollout with RK4.

    Integrates ``shat' = M(shat)^{-1} (a(shat) + J_p^T b(shat))`` with the mass
    matrix ``M = I + J_p^T G_lift J_p`` (``G_lift = Vbar^T Vbar``).  ``M`` is SPD
    with ``||M - I|| <= L^2 - 1``, so the linear solve is well conditioned
    whenever the manifold's Lipschitz budget is finite.
    """
    r = s0.shape[0]
    I = jnp.eye(r)
    ca, Aa, Na = a_ops["c"].reshape(-1), a_ops["A"], a_ops["N"]
    cb, Ab, Nb = b_ops["c"].reshape(-1), b_ops["A"], b_ops["N"]

    def rhs(s):
        p, Jp = feat_jac_fn(s)                       # (q,), (q, r)
        a = ca + Aa @ s + Na @ p
        b = cb + Ab @ s + Nb @ p
        M = I + Jp.T @ (G_lift @ Jp)
        return jnp.linalg.solve(M, a + Jp.T @ b)

    def rk4_step(s, _):
        k1 = rhs(s)
        k2 = rhs(s + 0.5 * dt * k1)
        k3 = rhs(s + 0.5 * dt * k2)
        k4 = rhs(s + dt * k3)
        s_next = s + (dt / 6.0) * (k1 + 2 * k2 + 2 * k3 + k4)
        return s_next, s_next

    _, traj = jax.lax.scan(rk4_step, s0, None, length=n_steps)
    return traj


def simulate_rpg(a_ops: Dict[str, np.ndarray], b_ops: Dict[str, np.ndarray],
                 feat_jac_fn, G_lift: np.ndarray, s0: np.ndarray,
                 n_steps: int, dt: float) -> np.ndarray:
    """Simulate the geometric (RPG) manifold ROM; return latent ``(r, n_steps+1)``.

    ``a_ops`` model ``V^T f`` and ``b_ops`` model ``Vbar^T f`` (both learned by
    Operator Inference); ``feat_jac_fn(s) -> (p, J_p)`` supplies the shared
    features and their Jacobian; ``G_lift = Vbar^T Vbar``.
    """
    a_j = {k: jnp.asarray(v, dtype=jnp.float64) for k, v in a_ops.items()}
    b_j = {k: jnp.asarray(v, dtype=jnp.float64) for k, v in b_ops.items()}
    G_j = jnp.asarray(np.asarray(G_lift, dtype=float))
    s0_j = jnp.asarray(np.asarray(s0, dtype=float).reshape(-1))
    roll = jax.jit(_rpg_rollout, static_argnames=("feat_jac_fn", "n_steps"))
    traj = np.asarray(roll(a_j, b_j, feat_jac_fn, G_j, s0_j,
                           jnp.asarray(float(dt)), int(n_steps)))
    full = np.empty((traj.shape[1], n_steps + 1))
    full[:, 0] = np.asarray(s0_j)
    full[:, 1:] = traj.T
    return full


def simulate(ops: Dict[str, np.ndarray], feature_fn: FeatureFn | None,
             s0: np.ndarray, n_steps: int, dt: float,
             *, method: str = "rk4") -> np.ndarray:
    """Simulate the ROM and return the latent trajectory ``(r, n_steps+1)``.

    ``method`` is one of ``"rk4"``, ``"explicit"``, ``"semi_implicit"``
    (backward-Euler linear part), or ``"cnab"`` (Crank-Nicolson linear part,
    ``theta = 1/2``; the nonlinear term stays explicit Euler here, which is
    adequate for the mildly nonlinear advection-diffusion ROM).
    """
    ops_j = {k: jnp.asarray(v, dtype=jnp.float64) for k, v in ops.items()}
    s0_j = jnp.asarray(np.asarray(s0, dtype=float).reshape(-1))
    dt_j = jnp.asarray(float(dt))
    if method in ("rk4", "explicit"):
        rhs = _make_rhs(ops_j, feature_fn)
        traj = _rollout(rhs, s0_j, dt_j, int(n_steps), method)
    elif method in ("semi_implicit", "cnab"):
        theta = 1.0 if method == "semi_implicit" else 0.5
        traj = _rollout_semi_implicit(
            ops_j, feature_fn, s0_j, dt_j, int(n_steps), theta=theta)
    else:
        raise ValueError(f"Unknown integration method {method!r}.")
    traj = np.asarray(traj)                        # (n_steps, r)
    full = np.empty((traj.shape[1], n_steps + 1))
    full[:, 0] = np.asarray(s0_j)
    full[:, 1:] = traj.T
    return full


# ===========================================================================
# Feature-function builders (model-type aware)
# ===========================================================================


def opm_feature_fn(inner) -> FeatureFn:
    """Active orthogonal-polynomial features of a fitted :class:`GreedyOPM`."""
    from greedyopm.polynomials.arnoldi import arnoldi_eval
    basis = inner.arnoldi_basis_
    active = jnp.asarray(np.asarray(inner.active_nl_global_))

    def feats(s):
        Psi = arnoldi_eval(s.reshape(-1, 1), basis)   # (M, 1)
        return Psi[active, 0]
    return feats


def opm_feature_jac_fn(inner):
    """Active OPM features and their Jacobian ``(p, J_p)`` at a single point.

    ``J_p`` has shape ``(q, r)`` with ``J_p[k, j] = d psi_k / d shat_j``; both
    come from the differentiated Arnoldi recurrence, so the ROM's manifold
    metric reuses the exact gradients the certificate is built on.
    """
    from greedyopm.polynomials.arnoldi import arnoldi_eval_grad
    basis = inner.arnoldi_basis_
    active = jnp.asarray(np.asarray(inner.active_nl_global_))

    def feats_jac(s):
        W, G = arnoldi_eval_grad(s.reshape(-1, 1), basis)   # (M,1), (M,r,1)
        return W[active, 0], G[active, :, 0]
    return feats_jac


def monomial_feature_fn(kind: str, active=None) -> FeatureFn:
    """Full (or active-column) quadratic / cubic monomial features."""
    from baselines import quadratic_features, cubic_features
    base = quadratic_features if kind == "quadratic" else cubic_features
    if active is None:
        def feats(s):
            return base(s.reshape(-1, 1))[:, 0]
    else:
        act = jnp.asarray(np.asarray(active))

        def feats(s):
            return base(s.reshape(-1, 1))[act, 0]
    return feats


def monomial_feature_jac_fn(kind: str, active=None):
    """Monomial features and their Jacobian ``(p, J_p)`` by forward-mode AD."""
    feats = monomial_feature_fn(kind, active)

    def feats_jac(s):
        p = feats(s)
        Jp = jax.jacfwd(feats)(s)
        return p, Jp
    return feats_jac


# ===========================================================================
# Nonlinear feature values on a coordinate matrix (for the regression)
# ===========================================================================


def eval_features_matrix(feature_fn: FeatureFn | None,
                         Shat: np.ndarray) -> np.ndarray | None:
    """Evaluate ``feature_fn`` columnwise on ``Shat`` (r, k) -> (q, k)."""
    if feature_fn is None:
        return None
    Shat_j = jnp.asarray(np.asarray(Shat, dtype=float))
    P = jax.vmap(feature_fn, in_axes=1, out_axes=1)(Shat_j)
    return np.asarray(P)


# ===========================================================================
# Errors
# ===========================================================================


def relative_state_error(S_true: np.ndarray, S_approx: np.ndarray) -> float:
    """Relative Frobenius trajectory error ``||S_true - S_approx|| / ||S_true||``.

    Returns ``inf`` if the reconstruction contains non-finite values (a diverged
    ROM), matching the Julia ``compute_trajectory_error`` convention.
    """
    S_approx = np.asarray(S_approx)
    if not np.all(np.isfinite(S_approx)):
        return float("inf")
    S_true = np.asarray(S_true)
    return float(np.linalg.norm(S_true - S_approx) / np.linalg.norm(S_true))
