"""Parametric trajectory data for the OpInf + Greedy-OPM experiment.

Re-uses the exact spectral advection-diffusion solver of the reconstruction
experiment (:mod:`problem`), organised as **per-parameter trajectories** on a
common uniform time grid -- the layout Operator Inference needs.

The varied parameter is the wave speed ``c``.  Three roles: ``train`` speeds
(the manifold is fit on all of them jointly and one operator set is learned per
speed), one interior ``interp`` speed (operators by spline interpolation), and
one ``extrap`` speed beyond the range (operators by affine extrapolation).

Every trajectory starts from the same Gaussian pulse (the initial condition is
parameter-independent), so the parametric variation lives entirely in the
dynamics.

Two physical regimes are provided:

* ``resolved``       -- wider pulse, stronger diffusion: the reduced dynamics
  are smooth and the geometric ROM is stable across the parameter range.
* ``reconstruction`` -- the narrow pulse / weak diffusion of the reconstruction
  experiment: a stiff, advection-dominated stress test.

The manifold is fit on a lightly strided concatenation of the training
trajectories; the stride is chosen so the fit column count stays well above the
number of polynomial features (a rank-deficient Vandermonde-Arnoldi build would
otherwise corrupt the high-degree features).
"""

from __future__ import annotations

from typing import Dict, List

import numpy as np

import problem as prob

# ---- parameter regime (physical) -------------------------------------------

REGIMES = {
    "gentle": dict(nu=2e-3, pulse_w=8e-3),
    "resolved": dict(nu=5e-4, pulse_w=3e-3),
    "reconstruction": dict(nu=1e-4, pulse_w=1e-3),
}

# ---- parameter regime (speed) ----------------------------------------------

C_MIN = 1.0
C_MAX = 5.0
TRAIN_SPEEDS = [1.0, 2.0, 3.0, 4.0, 5.0]
INTERP_SPEED = 3.3
EXTRAP_SPEED = 6.5

# ---- temporal discretization -----------------------------------------------

T_WINDOW = 0.35
N_TIME = 500
FIT_STRIDE = 2          # fit columns = P * N_TIME / FIT_STRIDE = 1250


def _trajectory(c: float, t: np.ndarray, nu: float, pulse_w: float) -> np.ndarray:
    S, _ = prob.solve_advection_diffusion(float(c), t, nu=nu, pulse_w=pulse_w)
    return np.ascontiguousarray(S)


def make_opinf_dataset(regime: str = "resolved") -> Dict:
    """Assemble the train / interp / extrap trajectory dataset for a regime."""
    if regime not in REGIMES:
        raise ValueError(f"Unknown regime {regime!r}; choose {list(REGIMES)}.")
    phys = REGIMES[regime]
    nu, pw = phys["nu"], phys["pulse_w"]

    t = np.linspace(0.0, T_WINDOW, N_TIME, endpoint=False)
    dt = float(t[1] - t[0])
    x = np.linspace(0.0, 1.0, prob.NX, endpoint=False)

    blocks: List[np.ndarray] = [_trajectory(c, t, nu, pw) for c in TRAIN_SPEEDS]
    fit_blocks = [blk[:, ::FIT_STRIDE] for blk in blocks]
    S_fit = np.concatenate(fit_blocks, axis=1)

    return dict(
        regime=regime, nu=nu, pulse_w=pw,
        t=t, dt=dt, x=x,
        train=dict(
            speeds=[float(c) for c in TRAIN_SPEEDS],
            blocks=blocks,
            S_fit=S_fit,
            n_fit=fit_blocks[0].shape[1],
        ),
        interp=dict(c=float(INTERP_SPEED), S=_trajectory(INTERP_SPEED, t, nu, pw)),
        extrap=dict(c=float(EXTRAP_SPEED), S=_trajectory(EXTRAP_SPEED, t, nu, pw)),
    )


def summary(data: Dict) -> str:
    d = data["train"]["blocks"][0].shape[0]
    P = len(data["train"]["speeds"])
    return (
        f"regime={data['regime']} nu={data['nu']:g} pw={data['pulse_w']:g}  "
        f"d={d} P_train={P} speeds={data['train']['speeds']}  "
        f"N_time={N_TIME} dt={data['dt']:.2e} T={T_WINDOW}  "
        f"fit_cols={data['train']['S_fit'].shape[1]}  "
        f"interp={data['interp']['c']} extrap={data['extrap']['c']}"
    )
