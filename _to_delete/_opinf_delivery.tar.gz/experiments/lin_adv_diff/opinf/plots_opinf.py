"""Plotting for the OpInf + Greedy-OPM experiment (journal-quality).

Figures are written as ``.png`` (300 dpi) and vector ``.pdf`` with no titles.

* :func:`error_vs_r`        -- relative state error vs r (train / interp /
  extrap panels), one line per method (geometric RPG ROM).
* :func:`budget_study_plot` -- ROM interp / extrap error and the selection
  objective vs the Lipschitz budget L, with the selected L* marked.
* :func:`trajectory_panels` -- space-time truth vs decoded ROM and |error| for
  the interpolated and extrapolated speeds.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt   # noqa: E402

from methods import METHOD_STYLES  # noqa: E402

plt.rcParams.update({
    "font.family": "serif",
    "mathtext.fontset": "cm",
    "axes.labelsize": 18,
    "axes.titlesize": 18,
    "xtick.labelsize": 14,
    "ytick.labelsize": 14,
    "legend.fontsize": 13,
    "axes.linewidth": 1.1,
    "xtick.direction": "in",
    "ytick.direction": "in",
    "lines.linewidth": 2.2,
    "savefig.dpi": 300,
    "savefig.bbox": "tight",
    "pdf.fonttype": 42,
})

_CAP = 2.0                      # display cap for diverged (huge / inf) errors


def _save(fig, out: str) -> None:
    Path(out).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out + ".png")
    fig.savefig(out + ".pdf")
    plt.close(fig)


def _series(results, RS, name, field):
    xs, ys = [], []
    for r in RS:
        key = f"{name}@r={r}"
        if key in results:
            v = results[key].get(field)
            if v is None:
                continue
            xs.append(r)
            ys.append(min(float(v), _CAP) if np.isfinite(v) else _CAP)
    return np.asarray(xs), np.asarray(ys)


def error_vs_r(results, RS, methods, out: str) -> None:
    """Relative state error vs r: training (median), interpolation, extrapolation."""
    fields = [("train_median", "Training (median over speeds)"),
              ("interp", "Interpolated speed"),
              ("extrap", "Extrapolated speed")]
    fig, axes = plt.subplots(1, 3, figsize=(16.5, 5.0), sharey=True)
    for ax, (field, title) in zip(axes, fields):
        for name in methods:
            st = METHOD_STYLES.get(name, dict(fmt="-o", color="gray", lw=2, ms=6))
            xs, ys = _series(results, RS, name, field)
            if xs.size:
                ax.plot(xs, ys, st["fmt"], color=st["color"], lw=st["lw"],
                        ms=st["ms"], label=name)
        ax.set_yscale("log")
        ax.set_xlabel(r"reduced dimension $r$")
        ax.set_title(title)
        ax.grid(True, which="both", ls=":", alpha=0.4)
        ax.axhline(_CAP, color="k", ls="--", lw=0.8, alpha=0.5)
    axes[0].set_ylabel(r"relative state error")
    axes[0].legend(loc="best", framealpha=0.92)
    fig.text(0.5, -0.02,
             r"dashed line: divergence cap (ROM error $\geq %.0f$ shown clipped)" % _CAP,
             ha="center", fontsize=12)
    _save(fig, out)


def budget_study_plot(study, out: str) -> None:
    """ROM interp / extrap error and selection objective vs the budget L."""
    names = list(study.keys())
    fig, axes = plt.subplots(1, len(names), figsize=(7.5 * len(names), 5.2),
                             squeeze=False)
    for ax, name in zip(axes[0], names):
        curve = sorted(study[name]["curve"], key=lambda d: d["L"])
        L = np.array([c["L"] for c in curve])
        ei = np.clip([c["interp"] for c in curve], None, 1e3)
        ee = np.clip([c["extrap"] for c in curve], None, 1e3)
        obj = np.clip([c["objective"] for c in curve], None, 1e3)
        ax.plot(L, ei, "-P", color="#9467bd", label="interp. ROM error", ms=6)
        ax.plot(L, ee, "-D", color="#d62728", label="extrap. ROM error", ms=6)
        ax.plot(L, obj, "-o", color="black", lw=2.4, label="selection objective", ms=5)
        ax.axvline(study[name]["L_star"], color="green", ls="--", lw=1.8,
                   label=r"selected $L^\ast=%.3g$" % study[name]["L_star"])
        ax.set_xscale("log")
        ax.set_yscale("log")
        ax.set_xlabel(r"Lipschitz budget $L$")
        ax.set_title(name)
        ax.grid(True, which="both", ls=":", alpha=0.4)
    axes[0][0].set_ylabel(r"relative state error / objective")
    axes[0][0].legend(loc="best", framealpha=0.92)
    _save(fig, out)


def trajectory_panels(data, regime, RS, out: str, cfg, ref_L, results) -> None:
    """Space-time truth vs decoded ROM and |error| for interp and extrap speeds."""
    import parametric
    from opinf_methods import ManifoldROM

    r = min(5, max(RS))
    key = f"Greedy-OPM (p=3)@r={r}"
    if key not in results:
        return
    L_star = results[key].get("L") or ref_L

    S_fit = data["train"]["S_fit"]
    pod = ManifoldROM("POD", r, S_fit, cfg=cfg)
    opm = ManifoldROM("Greedy-OPM (p=3)", r, S_fit, L=L_star, cfg=cfg)
    dec_pod = parametric.decoded_trajectories(pod, data, kind="rpg")
    dec_opm = parametric.decoded_trajectories(opm, data, kind="rpg")

    t, x = data["t"], data["x"]
    extent = [t[0], t[-1], x[0], x[-1]]
    for split, label in (("interp", f"interpolated  c={data['interp']['c']}"),
                         ("extrap", f"extrapolated  c={data['extrap']['c']}")):
        truth = np.asarray(data[split]["S"])
        rp, ro = dec_pod[split], dec_opm[split]
        finite = np.all(np.isfinite(ro))
        vmax = float(np.max(np.abs(truth)))
        fig, ax = plt.subplots(2, 3, figsize=(15, 7.6))
        panels = [
            (truth, "Truth", dict(vmin=-vmax, vmax=vmax, cmap="RdBu_r")),
            (rp, r"POD ROM ($r=%d$)" % r, dict(vmin=-vmax, vmax=vmax, cmap="RdBu_r")),
            (ro, r"Greedy-OPM ($p{=}3$) RPG ROM", dict(vmin=-vmax, vmax=vmax, cmap="RdBu_r")),
        ]
        for a, (Z, ttl, kw) in zip(ax[0], panels):
            a.imshow(Z, aspect="auto", origin="lower", extent=extent, **kw)
            a.set_title(ttl)
            a.set_xlabel(r"$t$"); a.set_ylabel(r"$x$")
        # error rows
        ep = np.abs(rp - truth)
        eo = np.abs(ro - truth) if finite else np.full_like(truth, np.nan)
        emax = float(np.nanmax([ep.max(), np.nanmax(eo) if finite else 0.0])) or 1.0
        ax[1, 0].axis("off")
        for a, (E, ttl) in zip(ax[1, 1:], [(ep, "POD |error|"),
                                           (eo, "Greedy-OPM |error|")]):
            im = a.imshow(E, aspect="auto", origin="lower", extent=extent,
                          vmin=0, vmax=emax, cmap="magma")
            a.set_title(ttl)
            a.set_xlabel(r"$t$"); a.set_ylabel(r"$x$")
            fig.colorbar(im, ax=a, fraction=0.046, pad=0.04)
        fig.suptitle("")
        _save(fig, f"{out}_{split}")
