"""Driver: OpInf + Greedy-OPM reduced-order models on advection-diffusion.

Trains a Greedy-OPM (and POD / Greedy-CM) manifold jointly on several training
wave speeds, learns one reduced operator set per speed by Operator Inference
with fourth-order finite-difference derivatives, simulates the reduced model,
and decodes with the manifold.  Reduced models are evaluated at the training
speeds, at an interpolated speed (operators by cubic-spline interpolation), and
at an extrapolated speed (operators by affine extrapolation).

Two reduced-model families are compared:

* the **plain latent OpInf** model (Geelen-style) -- the requested baseline,
  which for a polynomial manifold on this advection problem is dynamically
  unstable; its divergence is recorded, not hidden;
* the **geometric manifold-Galerkin (RPG-OpInf)** model, whose mass matrix is
  bounded by the manifold's Lipschitz budget, and whose budget is selected to
  keep the simulated latent stable while beating POD at low reduced dimension.

Phases (resumable via JSON checkpoints):

* ``sweep``  -- every method for r = 1..R_MAX; each OPM variant selects its own
  ROM-stabilizing budget per r.
* ``plots``  -- relative-state-error-vs-r curves, the budget study, and
  interp/extrap space-time panels.
* ``report`` -- the journal-reportable quantities as one JSON.
* ``all``    -- everything above, in order.

Usage:  ``python run_opinf.py [phase] [regime]``
        phase in {all, sweep, plots, report};  regime in {gentle, resolved}.
"""

from __future__ import annotations

import json
import sys
import time
from pathlib import Path

import numpy as np
import jax

jax.config.update("jax_enable_x64", True)

_HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(_HERE))
sys.path.insert(0, str(_HERE.parent))                 # problem, methods, baselines
sys.path.insert(0, str(_HERE.parent.parent.parent / "src"))  # greedyopm

import methods as M                                   # noqa: E402
import problem_opinf as P                             # noqa: E402
import parametric                                     # noqa: E402
from opinf_methods import ManifoldROM                 # noqa: E402
from budget_select_rom import select_budget_rom       # noqa: E402

# ---- configuration ----------------------------------------------------------

R_MAX = 6
RS = list(range(1, R_MAX + 1))
R_BUDGET_CURVE = 5                        # r at which the budget curve is drawn

DELTA = 1.0                              # ROM-appropriate certificate collar
REF_L = 1.0e3                            # reference (loose) budget for the fit
MANIFOLD_CFG = dict(M.CFG)
MANIFOLD_CFG.update(s_pool=18, n_grad_samples=140, n_reorth=3, delta=DELTA)

METHODS = ["POD", "Greedy-CM", "Greedy-OPM (p=2)", "Greedy-OPM (p=3)"]
OPM_METHODS = ("Greedy-OPM (p=2)", "Greedy-OPM (p=3)")

PLOTS = _HERE / "plots"


def _paths(regime: str):
    tag = f"opinf_{regime}"
    return (PLOTS / f"{tag}_results.json",
            PLOTS / f"{tag}_budget.json",
            PLOTS / f"{tag}_report.json",
            tag)


def _load(path: Path) -> dict:
    return json.loads(path.read_text()) if path.exists() else {}


def _save(path: Path, obj: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=0))


# ---------------------------------------------------------------------------
# Sweep
# ---------------------------------------------------------------------------


def run_budget(data: dict, regime: str) -> dict:
    """Select one ROM-stabilizing budget per OPM variant (at a reference r)."""
    _, ckpt_b, _, _ = _paths(regime)
    study = _load(ckpt_b)
    S_fit = data["train"]["S_fit"]
    for name in OPM_METHODS:
        if name in study and "L_star" in study[name]:
            print(f"  [budget] {name}: cached L*={study[name]['L_star']:.3g}",
                  flush=True)
            continue
        tic = time.time()
        mrom = ManifoldROM(name, R_BUDGET_CURVE, S_fit, L=REF_L, cfg=MANIFOLD_CFG)
        sel = select_budget_rom(mrom, data, log=print)
        sel["secs"] = round(time.time() - tic, 1)
        study[name] = sel
        _save(ckpt_b, study)
        print(f"  [budget] {name}: L*={sel['L_star']:.3g} "
              f"(obj {sel['best_objective']:.3e}, {sel['secs']}s)", flush=True)
    return study


def resolve_Ls(regime: str) -> dict:
    _, ckpt_b, _, _ = _paths(regime)
    study = _load(ckpt_b)
    Ls = {n: study[n]["L_star"] for n in OPM_METHODS
          if n in study and "L_star" in study[n]}
    if len(Ls) != len(OPM_METHODS):
        raise RuntimeError("Budget not selected; run the 'budget' phase first.")
    return Ls


def run_sweep(data: dict, regime: str, Ls: dict) -> dict:
    """Fit every method at every r; each OPM variant uses its selected budget."""
    ckpt, _, _, _ = _paths(regime)
    results = _load(ckpt)
    S_fit = data["train"]["S_fit"]

    for r in RS:
        for name in METHODS:
            key = f"{name}@r={r}"
            if key in results:
                continue
            tic = time.time()
            is_opm = name in OPM_METHODS
            L_star = Ls.get(name) if is_opm else None
            mrom = ManifoldROM(name, r, S_fit, L=L_star, cfg=MANIFOLD_CFG)

            rpg = parametric.evaluate(mrom, data, kind="rpg")
            rec = dict(method=name, r=r, rom="rpg", L=L_star,
                       delta=DELTA, **rpg, secs=round(time.time() - tic, 1))

            # plain latent OpInf (the unstable baseline) for the manifold methods
            if name != "POD":
                plain = parametric.evaluate(mrom, data, kind="plain")
                rec["plain_interp"] = plain["interp"]
                rec["plain_extrap"] = plain["extrap"]
                rec["plain_train_median"] = plain["train_median"]

            results[key] = rec
            _save(ckpt, results)
            Lstr = "n/a" if L_star is None else f"{L_star:.3g}"
            print(f"  r={r:2d}  {name:18s} L*={Lstr:<8} nfeat={rpg['n_features']:>3d} "
                  f"train={rpg['train_median']:.2e} interp={rpg['interp']:.2e} "
                  f"extrap={rpg['extrap']:.2e}  ({rec['secs']}s)", flush=True)
    return results


# ---------------------------------------------------------------------------
# Plots / report
# ---------------------------------------------------------------------------


def run_plots(data: dict, regime: str) -> None:
    from plots_opinf import error_vs_r, budget_study_plot, trajectory_panels
    ckpt, ckpt_b, _, tag = _paths(regime)
    results = _load(ckpt)
    error_vs_r(results, RS, METHODS, str(PLOTS / f"{tag}_error_vs_r"))
    study = _load(ckpt_b)
    if study:
        budget_study_plot(study, str(PLOTS / f"{tag}_budget_study"))
    trajectory_panels(data, regime, RS, str(PLOTS / f"{tag}_field"),
                      MANIFOLD_CFG, REF_L, results)


def run_report(data: dict, regime: str) -> dict:
    ckpt, ckpt_b, report_path, tag = _paths(regime)
    results = _load(ckpt)
    study = _load(ckpt_b)
    errors = {}
    for name in METHODS:
        errors[name] = {
            str(r): {k: results[f"{name}@r={r}"][k]
                     for k in ("train_median", "interp", "extrap",
                               "n_features", "L")}
            for r in RS if f"{name}@r={r}" in results
        }
    report = dict(
        experiment="lin_adv_diff/opinf",
        regime=regime,
        nu=data["nu"], pulse_w=data["pulse_w"],
        train_speeds=data["train"]["speeds"],
        interp_speed=data["interp"]["c"], extrap_speed=data["extrap"]["c"],
        n_time=P.N_TIME, dt=data["dt"], T=P.T_WINDOW,
        delta=DELTA, r_max=R_MAX,
        selected_budgets={n: study[n]["L_star"] for n in OPM_METHODS if n in study},
        errors=errors,
    )
    _save(report_path, report)
    print(f"    saved {report_path.name}", flush=True)
    return report


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------


def main(phase: str = "all", regime: str = "gentle") -> None:
    data = P.make_opinf_dataset(regime)
    print(f"[opinf/{regime}] {P.summary(data)}  delta={DELTA} phase={phase}",
          flush=True)
    if phase in ("all", "budget"):
        run_budget(data, regime)
    if phase in ("all", "sweep"):
        Ls = resolve_Ls(regime)
        print(f"[opinf/{regime}] budgets: "
              + ", ".join(f"{k}->L*={v:.3g}" for k, v in Ls.items()), flush=True)
        run_sweep(data, regime, Ls)
    if phase in ("all", "plots"):
        run_plots(data, regime)
    if phase in ("all", "report"):
        run_report(data, regime)
    print("DONE", flush=True)


if __name__ == "__main__":
    ph = sys.argv[1] if len(sys.argv) > 1 else "all"
    rg = sys.argv[2] if len(sys.argv) > 2 else "gentle"
    t0 = time.time()
    main(ph, rg)
    print(f"[opinf/{rg}] elapsed {time.time() - t0:.1f}s", flush=True)
